"""Sole shared interface authority for the Weight-Frozen Programmatic Agent.

Every later module imports its public types from here. Data-contract
validation lives here and nowhere else; persistence, hashing, model calls,
AST parsing, and security policy do not.

The JSON value universe is deliberately narrow: ``None``, ``bool``, finite
``int``/``float``, ``str``, ``list``, and ``dict[str, JSONValue]``. NaN,
infinities, non-string object keys, and arbitrary Python objects are
rejected at the validation boundary.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping, Protocol, Sequence, TypeAlias, runtime_checkable

__all__ = [
    "JSONValue",
    "validate_json_value",
    "ModelTier",
    "RunStatus",
    "EvaluationSplit",
    "Budget",
    "TaskSpec",
    "Transition",
    "SkillArtifact",
    "ModelRequest",
    "ModelResponse",
    "EvaluationResult",
    "GateDecision",
    "ExecutionResult",
    "PatchProposal",
    "TasteFeatures",
    "TasteReport",
    "RunReport",
    "ModelBackend",
    "MemoryStore",
    "SkillResolver",
    "SkillExecutor",
    "CandidateEvaluator",
]

JSONValue: TypeAlias = (
    None | bool | int | float | str | list["JSONValue"] | dict[str, "JSONValue"]
)

_MAX_JSON_DEPTH = 64
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_ERROR_CODE = re.compile(r"^[A-Z][A-Z0-9_]{0,63}$")
_SKILL_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


# --------------------------------------------------------------------------
# JSON value validation
# --------------------------------------------------------------------------


def validate_json_value(value: Any, *, path: str = "$", _depth: int = 0) -> None:
    """Raise ``TypeError``/``ValueError`` unless *value* is a JSON value.

    The path is a structural location only; it never echoes the value, so
    calling this on sensitive data does not leak it into an error message.
    """
    if _depth > _MAX_JSON_DEPTH:
        raise ValueError(f"{path}: nesting deeper than {_MAX_JSON_DEPTH}")
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, int):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"{path}: non-finite float is not a JSON value")
        return
    if isinstance(value, str):
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            validate_json_value(item, path=f"{path}[{index}]", _depth=_depth + 1)
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(f"{path}: object key must be str, not {type(key).__name__}")
            validate_json_value(item, path=f"{path}.{key}", _depth=_depth + 1)
        return
    raise TypeError(f"{path}: {type(value).__name__} is not a JSON value")


# --------------------------------------------------------------------------
# Enumerations
# --------------------------------------------------------------------------


class ModelTier(str, Enum):
    PRIMARY = "PRIMARY"
    ESCALATION = "ESCALATION"


class RunStatus(str, Enum):
    OK = "OK"
    NO_CANDIDATE = "NO_CANDIDATE"
    BLOCKED = "BLOCKED"
    INCONCLUSIVE = "INCONCLUSIVE"
    ERROR = "ERROR"


class EvaluationSplit(str, Enum):
    DEV = "DEV"
    VALIDATION = "VALIDATION"
    TEST = "TEST"


# --------------------------------------------------------------------------
# Private validation helpers (data contract only)
# --------------------------------------------------------------------------


def _require_bool(name: str, value: Any) -> None:
    if not isinstance(value, bool):
        raise TypeError(f"{name} must be bool")


def _require_int(name: str, value: Any, *, minimum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{name} must be int")
    if minimum is not None and value < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return value


def _require_float(
    name: str,
    value: Any,
    *,
    minimum: float | None = None,
    maximum: float | None = None,
) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    if minimum is not None and number < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    if maximum is not None and number > maximum:
        raise ValueError(f"{name} must be <= {maximum}")
    return number


def _require_str(name: str, value: Any, *, non_empty: bool = True) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{name} must be str")
    if non_empty and not value:
        raise ValueError(f"{name} must be non-empty")
    return value


def _str_tuple(name: str, value: Any, *, allow_empty: bool = True) -> tuple[str, ...]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise TypeError(f"{name} must be a sequence of str")
    items = tuple(value)
    for item in items:
        if not isinstance(item, str):
            raise TypeError(f"{name} entries must be str")
        if not item:
            raise ValueError(f"{name} entries must be non-empty")
    if not allow_empty and not items:
        raise ValueError(f"{name} must not be empty")
    return items


def _json_copy(value: Any) -> JSONValue:
    """Defensive deep copy of an already-validated JSON value."""
    if isinstance(value, list):
        return [_json_copy(item) for item in value]
    if isinstance(value, dict):
        return {key: _json_copy(item) for key, item in value.items()}
    return value


def _frozen_mapping(name: str, value: Any) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a mapping")
    for key in value:
        if not isinstance(key, str):
            raise TypeError(f"{name} keys must be str")
    copied = dict(value)
    validate_json_value(copied)
    return MappingProxyType(copied)


# --------------------------------------------------------------------------
# Budget
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Budget:
    """Per-run hard limits. Defaults come from ``MASTER_PROMPT.md``."""

    max_model_calls: int = 10
    max_total_output_tokens: int = 16000
    max_tokens_per_call: int = 2048
    max_prompt_chars: int = 8192
    max_candidate_evaluations: int = 32
    max_mcts_simulations: int = 64
    max_search_depth: int = 8
    max_skill_steps: int = 5000
    max_artifact_bytes: int = 32768
    max_payload_bytes: int = 262144
    deadline_seconds: float = 60.0

    def __post_init__(self) -> None:
        _require_int("max_model_calls", self.max_model_calls, minimum=1)
        _require_int("max_total_output_tokens", self.max_total_output_tokens, minimum=1)
        _require_int("max_tokens_per_call", self.max_tokens_per_call, minimum=1)
        _require_int("max_prompt_chars", self.max_prompt_chars, minimum=1)
        _require_int("max_candidate_evaluations", self.max_candidate_evaluations, minimum=1)
        _require_int("max_mcts_simulations", self.max_mcts_simulations, minimum=1)
        _require_int("max_search_depth", self.max_search_depth, minimum=1)
        _require_int("max_skill_steps", self.max_skill_steps, minimum=1)
        _require_int("max_artifact_bytes", self.max_artifact_bytes, minimum=1)
        _require_int("max_payload_bytes", self.max_payload_bytes, minimum=1)
        _require_float("deadline_seconds", self.deadline_seconds)
        if float(self.deadline_seconds) <= 0.0:
            raise ValueError("deadline_seconds must be > 0")
        if self.max_tokens_per_call > self.max_total_output_tokens:
            raise ValueError("max_tokens_per_call must not exceed max_total_output_tokens")
        if self.max_artifact_bytes > self.max_payload_bytes:
            raise ValueError("max_artifact_bytes must not exceed max_payload_bytes")


# --------------------------------------------------------------------------
# Tasks and transitions
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TaskSpec:
    task_id: str
    instruction: str
    payload: JSONValue
    output_schema: JSONValue | None = None
    seed: int = 0

    def __post_init__(self) -> None:
        _require_str("task_id", self.task_id)
        _require_str("instruction", self.instruction)
        validate_json_value(self.payload, path="$payload")
        object.__setattr__(self, "payload", _json_copy(self.payload))
        if self.output_schema is not None:
            validate_json_value(self.output_schema, path="$output_schema")
            object.__setattr__(self, "output_schema", _json_copy(self.output_schema))
        _require_int("seed", self.seed, minimum=0)


@dataclass(frozen=True, slots=True)
class Transition:
    episode_id: str
    step_index: int
    observation: JSONValue
    action: JSONValue
    next_observation: JSONValue
    reward: float
    terminal: bool

    def __post_init__(self) -> None:
        _require_str("episode_id", self.episode_id)
        _require_int("step_index", self.step_index, minimum=0)
        validate_json_value(self.observation, path="$observation")
        object.__setattr__(self, "observation", _json_copy(self.observation))
        validate_json_value(self.action, path="$action")
        object.__setattr__(self, "action", _json_copy(self.action))
        validate_json_value(self.next_observation, path="$next_observation")
        object.__setattr__(self, "next_observation", _json_copy(self.next_observation))
        object.__setattr__(self, "reward", _require_float("reward", self.reward, minimum=0.0, maximum=1.0))
        _require_bool("terminal", self.terminal)


@dataclass(frozen=True, slots=True)
class SkillArtifact:
    skill_id: str
    version: int
    source: str
    description: str
    input_schema: JSONValue
    output_schema: JSONValue
    depends_on: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.skill_id, str) or not _SKILL_ID.match(self.skill_id):
            raise ValueError("skill_id must be 1-64 chars matching [A-Za-z0-9][A-Za-z0-9_.-]*")
        _require_int("version", self.version, minimum=1)
        _require_str("source", self.source)
        _require_str("description", self.description)
        validate_json_value(self.input_schema, path="$input_schema")
        object.__setattr__(self, "input_schema", _json_copy(self.input_schema))
        validate_json_value(self.output_schema, path="$output_schema")
        object.__setattr__(self, "output_schema", _json_copy(self.output_schema))
        deps = _str_tuple("depends_on", self.depends_on)
        for dep in deps:
            if not _SKILL_ID.match(dep):
                raise ValueError("depends_on entries must be valid skill ids")
            if dep == self.skill_id:
                raise ValueError("a skill may not depend on itself")
        if len(set(deps)) != len(deps):
            raise ValueError("depends_on entries must be unique")
        object.__setattr__(self, "depends_on", deps)


# --------------------------------------------------------------------------
# Model contracts
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ModelRequest:
    request_id: str
    tier: ModelTier
    prompt: str
    temperature: float
    max_tokens: int
    timeout_seconds: float = 20.0

    def __post_init__(self) -> None:
        _require_str("request_id", self.request_id)
        if not isinstance(self.tier, ModelTier):
            raise TypeError("tier must be a ModelTier")
        if not isinstance(self.prompt, str):
            raise TypeError("prompt must be str")
        object.__setattr__(
            self, "temperature", _require_float("temperature", self.temperature, minimum=0.0, maximum=2.0)
        )
        _require_int("max_tokens", self.max_tokens, minimum=1)
        timeout = _require_float("timeout_seconds", self.timeout_seconds)
        if timeout <= 0.0 or timeout > 30.0:
            raise ValueError("timeout_seconds must be > 0 and <= 30")
        object.__setattr__(self, "timeout_seconds", timeout)


@dataclass(frozen=True, slots=True)
class ModelResponse:
    text: str
    model_id: str
    input_tokens: int | None
    output_tokens: int | None
    latency_ms: int

    def __post_init__(self) -> None:
        if not isinstance(self.text, str):
            raise TypeError("text must be str")
        _require_str("model_id", self.model_id)
        if self.input_tokens is not None:
            _require_int("input_tokens", self.input_tokens, minimum=0)
        if self.output_tokens is not None:
            _require_int("output_tokens", self.output_tokens, minimum=0)
        _require_int("latency_ms", self.latency_ms, minimum=0)


# --------------------------------------------------------------------------
# Evaluation and gating
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class EvaluationResult:
    candidate_id: str
    split: EvaluationSplit
    task_ids: tuple[str, ...]
    scores: tuple[float, ...]
    metrics: Mapping[str, JSONValue] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _require_str("candidate_id", self.candidate_id)
        if not isinstance(self.split, EvaluationSplit):
            raise TypeError("split must be an EvaluationSplit")
        task_ids = _str_tuple("task_ids", self.task_ids, allow_empty=False)
        if len(set(task_ids)) != len(task_ids):
            raise ValueError("task_ids must be unique")
        if isinstance(self.scores, (str, bytes)) or not isinstance(self.scores, Sequence):
            raise TypeError("scores must be a sequence of numbers")
        scores = tuple(
            _require_float("score", score, minimum=0.0, maximum=1.0) for score in self.scores
        )
        if not scores:
            raise ValueError("scores must not be empty")
        if len(task_ids) != len(scores):
            raise ValueError("task_ids and scores must have equal length")
        object.__setattr__(self, "task_ids", task_ids)
        object.__setattr__(self, "scores", scores)
        object.__setattr__(self, "metrics", _frozen_mapping("metrics", self.metrics))

    @property
    def mean(self) -> float:
        return math.fsum(self.scores) / len(self.scores)


@dataclass(frozen=True, slots=True)
class GateDecision:
    accepted: bool
    mean_delta: float | None
    lower_confidence_bound: float | None
    alpha: float | None
    n: int
    complexity_penalty: float | None
    reasons: tuple[str, ...]

    def __post_init__(self) -> None:
        _require_bool("accepted", self.accepted)
        for name in ("mean_delta", "lower_confidence_bound", "alpha", "complexity_penalty"):
            value = getattr(self, name)
            if value is not None:
                setattr_ = _require_float(name, value)
                object.__setattr__(self, name, setattr_)
        _require_int("n", self.n, minimum=0)
        reasons = _str_tuple("reasons", self.reasons, allow_empty=False)
        object.__setattr__(self, "reasons", reasons)
        if self.accepted:
            if None in (self.mean_delta, self.lower_confidence_bound, self.alpha, self.complexity_penalty):
                raise ValueError("an accepted decision must carry all numeric fields")
        if self.alpha is not None and not 0.0 < self.alpha < 1.0:
            raise ValueError("alpha must be in (0, 1)")


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    status: RunStatus
    output: JSONValue | None
    steps: int
    elapsed_ms: int
    error_code: str | None

    def __post_init__(self) -> None:
        if not isinstance(self.status, RunStatus):
            raise TypeError("status must be a RunStatus")
        if self.output is not None:
            validate_json_value(self.output, path="$output")
        _require_int("steps", self.steps, minimum=0)
        _require_int("elapsed_ms", self.elapsed_ms, minimum=0)
        if self.error_code is not None:
            if not isinstance(self.error_code, str) or not _ERROR_CODE.match(self.error_code):
                raise ValueError("error_code must be an uppercase token like STEP_BUDGET_EXHAUSTED")
        if self.status is RunStatus.OK:
            if self.error_code is not None:
                raise ValueError("OK results must not carry an error_code")
        elif self.error_code is None:
            raise ValueError("non-OK results must carry an error_code")


@dataclass(frozen=True, slots=True)
class PatchProposal:
    base_sha256: str
    proposed_sha256: str
    unified_diff: str
    paths: tuple[str, ...]
    reason: str

    def __post_init__(self) -> None:
        for name in ("base_sha256", "proposed_sha256"):
            value = getattr(self, name)
            if not isinstance(value, str) or not _HEX64.match(value):
                raise ValueError(f"{name} must be 64 lowercase hex characters")
        _require_str("unified_diff", self.unified_diff)
        paths = _str_tuple("paths", self.paths, allow_empty=False)
        for path in paths:
            if path.startswith(("/", "\\")) or ".." in path or "\\" in path or "\x00" in path:
                raise ValueError("paths must be safe relative POSIX paths")
        if len(set(paths)) != len(paths):
            raise ValueError("paths must be unique")
        object.__setattr__(self, "paths", paths)
        _require_str("reason", self.reason)


# --------------------------------------------------------------------------
# Taste
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TasteFeatures:
    structural_richness: float
    visual_harmony: float | None
    novelty_similarity: float
    provenance: tuple[str, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "structural_richness",
            _require_float("structural_richness", self.structural_richness, minimum=0.0, maximum=1.0),
        )
        if self.visual_harmony is not None:
            object.__setattr__(
                self,
                "visual_harmony",
                _require_float("visual_harmony", self.visual_harmony, minimum=0.0, maximum=1.0),
            )
        object.__setattr__(
            self,
            "novelty_similarity",
            _require_float("novelty_similarity", self.novelty_similarity, minimum=0.0, maximum=1.0),
        )
        object.__setattr__(self, "provenance", _str_tuple("provenance", self.provenance))


@dataclass(frozen=True, slots=True)
class TasteReport:
    score: float | None
    available: bool
    components: Mapping[str, float]
    reason: str

    def __post_init__(self) -> None:
        _require_bool("available", self.available)
        if self.score is not None:
            object.__setattr__(self, "score", _require_float("score", self.score, minimum=0.0, maximum=1.0))
        if not isinstance(self.components, Mapping):
            raise TypeError("components must be a mapping of str to float")
        components: dict[str, float] = {}
        for key, value in self.components.items():
            if not isinstance(key, str):
                raise TypeError("components keys must be str")
            components[key] = _require_float(f"components[{key}]", value)
        object.__setattr__(self, "components", MappingProxyType(components))
        _require_str("reason", self.reason, non_empty=False)
        if self.available and self.score is None:
            raise ValueError("an available taste report must carry a score")
        if not self.available and self.score is not None:
            raise ValueError("an unavailable taste report must have score=None")


# --------------------------------------------------------------------------
# Run report
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class RunReport:
    run_id: str
    task_id: str
    status: RunStatus
    score: float | None
    budget_used: Mapping[str, int]
    candidate_id: str | None
    notes: tuple[str, ...]

    def __post_init__(self) -> None:
        _require_str("run_id", self.run_id)
        _require_str("task_id", self.task_id)
        if not isinstance(self.status, RunStatus):
            raise TypeError("status must be a RunStatus")
        if self.score is not None:
            object.__setattr__(self, "score", _require_float("score", self.score, minimum=0.0, maximum=1.0))
        if not isinstance(self.budget_used, Mapping):
            raise TypeError("budget_used must be a mapping of str to int")
        used: dict[str, int] = {}
        for key, value in self.budget_used.items():
            if not isinstance(key, str):
                raise TypeError("budget_used keys must be str")
            used[key] = _require_int(f"budget_used[{key}]", value, minimum=0)
        object.__setattr__(self, "budget_used", MappingProxyType(used))
        if self.candidate_id is not None:
            _require_str("candidate_id", self.candidate_id)
        object.__setattr__(self, "notes", _str_tuple("notes", self.notes))


# --------------------------------------------------------------------------
# Protocols
# --------------------------------------------------------------------------


@runtime_checkable
class ModelBackend(Protocol):
    def complete(self, request: ModelRequest) -> ModelResponse: ...


@runtime_checkable
class MemoryStore(Protocol):
    def append_event(self, event_type: str, payload: JSONValue) -> str: ...

    def list_events(
        self, event_type: str | None = None, limit: int = 100
    ) -> list[JSONValue]: ...


@runtime_checkable
class SkillResolver(Protocol):
    def get_approved(self, skill_id: str) -> SkillArtifact | None: ...


@runtime_checkable
class SkillExecutor(Protocol):
    def execute(
        self,
        skill: SkillArtifact,
        payload: JSONValue,
        budget: Budget,
        resolver: SkillResolver | None = None,
    ) -> ExecutionResult: ...


@runtime_checkable
class CandidateEvaluator(Protocol):
    def evaluate(
        self, candidate_id: str, task: TaskSpec, split: EvaluationSplit
    ) -> EvaluationResult: ...
