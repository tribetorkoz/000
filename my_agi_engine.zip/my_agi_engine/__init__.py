"""Weight-Frozen Programmatic Agent harness.

The learned model is fixed: ``d(theta_0)/dt = 0`` for every time step. This
package provides a bounded, standard-library-only harness that calls
already-trained models for inference and improves external artifacts
(memory, skills, search policies, inert proposals) only.

It is not a general intelligence and does not claim to be one.
"""

__all__ = ["contracts"]
