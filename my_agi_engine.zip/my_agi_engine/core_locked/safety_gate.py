"""Risk-controlled candidate acceptance gate (``safety_gate.py``).

One pure function answers one question: does a candidate's *paired validation
score* clear a Hoeffding lower bound by more than ``min_gain`` plus a
complexity penalty, with safety and independence attested?

A pass is **evidence only**. It is not runtime approval, it does not approve a
skill, and it must never change the trusted skill manifest. The caller decides
what to do with a pass; nothing in this module writes to a registry, a memory
store, or a file. It imports neither.

The rule, exactly as specified
------------------------------
For paired deltas ``d_i = c_i - b_i`` on the same ordered validation tasks::

    alpha_i   = alpha_total / num_comparisons          # Bonferroni, predeclared
    epsilon   = sqrt(2 * ln(1 / alpha_i) / n)          # Hoeffding, d_i in [-1, 1]
    LCB       = mean_delta - epsilon
    delta_DL  = max(0, candidate_dl_norm - baseline_dl_norm)
    penalty   = lambda_dl * delta_DL

Accept only when ``LCB > min_gain + penalty`` **and** ``safety_checks_passed``
**and** ``provenance_verified``. The comparison is strict.

Why this is a screen and not a proof
------------------------------------
The bound assumes the ``n`` paired tasks are independent draws from the target
distribution. A caller that cannot attest that independence must pass
``provenance_verified=False``, which refuses approval regardless of the math.
``num_comparisons`` must be declared before the results are seen; there is no
data-dependent alpha adjustment and no repeated peeking at the same validation
set. ``TEST`` is never admitted -- reserving it is what keeps the final number
honest.

Rejection is not an exception
-----------------------------
Malformed or inadmissible input yields ``GateDecision(accepted=False, ...)``
with every reason prefixed ``"INCONCLUSIVE: "``. The function does not raise on
bad input and it never approves by default. Numeric fields are ``None`` unless
the full paired calculation was actually performed; ``n`` reports the number of
paired samples the gate was willing to consider.

``GateDecision`` is frozen by the contract and has no ``alpha_total`` or
``num_comparisons`` field, so ``decision.alpha`` carries the per-comparison
alpha actually used in ``epsilon`` and the reason text records ``alpha_total``,
``num_comparisons``, ``min_gain``, ``lambda_dl``, the DL deltas, the penalty,
and the threshold alongside the result.
"""

from __future__ import annotations

import math
from typing import Any

from ..contracts import EvaluationResult, EvaluationSplit, GateDecision

__all__ = ["decide_candidate", "INCONCLUSIVE_PREFIX", "ACCEPTED_PREFIX"]

INCONCLUSIVE_PREFIX = "INCONCLUSIVE: "
ACCEPTED_PREFIX = "ACCEPTED: "

_MIN_PAIRED_SAMPLES = 2


# --------------------------------------------------------------------------
# Small, side-effect-free validators
# --------------------------------------------------------------------------


def _finite_real(value: Any) -> float | None:
    """Return ``value`` as a finite float, or ``None`` if it is not one.

    ``float()`` raises ``OverflowError`` for integers beyond float range
    (``10 ** 400``), so an oversized JSON integer is an invalid input rather
    than a crash: this gate must never raise on bad input.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        number = float(value)
    except (OverflowError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _unit_score(value: Any) -> float | None:
    """Return a score in ``[0, 1]``, or ``None`` when it is not one."""
    number = _finite_real(value)
    if number is None or number < 0.0 or number > 1.0:
        return None
    return number


def _num(value: float | None) -> str:
    """Deterministic, payload-free rendering of one number for a reason string."""
    return "None" if value is None else format(value, ".12g")


def _split_label(result: EvaluationResult) -> str:
    split = getattr(result, "split", None)
    return str(getattr(split, "value", split))


def _as_ordered_ids(value: Any) -> tuple[str, ...] | None:
    if isinstance(value, (str, bytes)) or not isinstance(value, (tuple, list)):
        return None
    if not all(isinstance(item, str) for item in value):
        return None
    return tuple(value)


def _as_scores(value: Any) -> tuple[Any, ...] | None:
    if isinstance(value, (str, bytes)) or not isinstance(value, (tuple, list)):
        return None
    return tuple(value)


def _reject(reasons: tuple[str, ...], n: int = 0) -> GateDecision:
    return GateDecision(
        accepted=False,
        mean_delta=None,
        lower_confidence_bound=None,
        alpha=None,
        n=max(0, int(n)),
        complexity_penalty=None,
        reasons=tuple(INCONCLUSIVE_PREFIX + reason for reason in reasons),
    )


def _summary(
    *,
    mean_delta: float,
    epsilon: float,
    lcb: float,
    alpha_total: float,
    num_comparisons: int,
    alpha_i: float,
    n: int,
    min_gain: float,
    lambda_dl: float,
    delta_dl: float,
    penalty: float,
    threshold: float,
) -> str:
    """Every numeric input and assumption, so a decision can be reproduced."""
    return (
        f"n={n}; mean_delta={_num(mean_delta)}; epsilon={_num(epsilon)}; "
        f"lcb={_num(lcb)}; alpha_total={_num(alpha_total)}; "
        f"num_comparisons={num_comparisons}; alpha_i={_num(alpha_i)}; "
        f"min_gain={_num(min_gain)}; lambda_dl={_num(lambda_dl)}; "
        f"delta_dl_norm={_num(delta_dl)}; complexity_penalty={_num(penalty)}; "
        f"threshold={_num(threshold)}"
    )


# --------------------------------------------------------------------------
# The gate
# --------------------------------------------------------------------------


def decide_candidate(
    baseline: EvaluationResult,
    candidate: EvaluationResult,
    *,
    alpha_total: float = 0.05,
    num_comparisons: int = 1,
    min_gain: float = 0.01,
    lambda_dl: float = 0.02,
    baseline_dl_norm: float,
    candidate_dl_norm: float,
    safety_checks_passed: bool,
    provenance_verified: bool,
) -> GateDecision:
    """Decide whether ``candidate`` beats ``baseline`` on paired validation scores.

    The decision is a screening result. ``accepted=True`` means "this candidate
    earned a further human look", never "this candidate is approved".
    """
    # -- structural admission ---------------------------------------------
    if not isinstance(baseline, EvaluationResult) or not isinstance(
        candidate, EvaluationResult
    ):
        return _reject(
            ("baseline and candidate must both be EvaluationResult instances",)
        )

    for label, result in (("baseline", baseline), ("candidate", candidate)):
        if getattr(result, "split", None) is EvaluationSplit.TEST:
            return _reject(
                (
                    f"{label} split is TEST; the TEST split is never admitted to "
                    "the acceptance gate",
                )
            )
    for label, result in (("baseline", baseline), ("candidate", candidate)):
        if getattr(result, "split", None) is not EvaluationSplit.VALIDATION:
            return _reject(
                (
                    f"{label} split must be VALIDATION, got {_split_label(result)}",
                )
            )

    # -- declared statistical parameters ----------------------------------
    alpha_total_value = _finite_real(alpha_total)
    if alpha_total_value is None or not 0.0 < alpha_total_value < 1.0:
        return _reject(("alpha_total must be a finite number strictly between 0 and 1",))

    if (
        isinstance(num_comparisons, bool)
        or not isinstance(num_comparisons, int)
        or num_comparisons < 1
    ):
        return _reject(
            (
                "num_comparisons must be an integer >= 1, declared before any "
                "result was observed",
            )
        )

    try:
        alpha_i = alpha_total_value / num_comparisons
    except (OverflowError, ValueError):
        # ``num_comparisons`` is an unbounded JSON integer; dividing by one
        # beyond float range must reject, not raise (A01-F5).
        return _reject(("per-comparison alpha_total / num_comparisons is not usable",))
    if not math.isfinite(alpha_i) or not 0.0 < alpha_i < 1.0:
        return _reject(("per-comparison alpha_total / num_comparisons is not usable",))

    min_gain_value = _finite_real(min_gain)
    if min_gain_value is None or not 0.0 <= min_gain_value <= 1.0:
        return _reject(("min_gain must be a finite number in [0, 1]",))

    lambda_value = _finite_real(lambda_dl)
    if lambda_value is None or lambda_value < 0.0:
        return _reject(("lambda_dl must be a finite number >= 0",))

    baseline_dl = _finite_real(baseline_dl_norm)
    candidate_dl = _finite_real(candidate_dl_norm)
    if (
        baseline_dl is None
        or candidate_dl is None
        or not 0.0 <= baseline_dl <= 1.0
        or not 0.0 <= candidate_dl <= 1.0
    ):
        return _reject(
            ("normalized DL inputs must be finite numbers in [0, 1]",)
        )

    if not isinstance(safety_checks_passed, bool):
        return _reject(("safety_checks_passed must be a bool",))
    if not isinstance(provenance_verified, bool):
        return _reject(("provenance_verified must be a bool",))

    # -- pairing ----------------------------------------------------------
    baseline_ids = _as_ordered_ids(baseline.task_ids)
    candidate_ids = _as_ordered_ids(candidate.task_ids)
    if baseline_ids is None or candidate_ids is None:
        return _reject(("task_ids must be sequences of strings on both results",))
    if not baseline_ids:
        return _reject(("task_ids must not be empty",))
    if baseline_ids != candidate_ids:
        return _reject(
            (
                "baseline and candidate task_ids must be identical and in the same "
                "order; unpaired score vectors cannot be compared",
            )
        )
    if len(set(baseline_ids)) != len(baseline_ids):
        return _reject(
            ("task_ids must be unique; duplicated tasks would be double-counted",)
        )

    baseline_scores = _as_scores(baseline.scores)
    candidate_scores = _as_scores(candidate.scores)
    if baseline_scores is None or candidate_scores is None:
        return _reject(("scores must be sequences of numbers on both results",))
    if not baseline_scores or not candidate_scores:
        return _reject(("score vectors must be non-empty",))
    if len(baseline_scores) != len(candidate_scores):
        return _reject(
            (
                "candidate and baseline must provide the same number of scores; got "
                f"{len(candidate_scores)} versus {len(baseline_scores)}",
            )
        )
    if len(baseline_scores) != len(baseline_ids):
        return _reject(
            ("score vectors must have one score per task_id",)
        )

    # -- paired deltas ----------------------------------------------------
    deltas: list[float] = []
    invalid_pairs = 0
    for baseline_score, candidate_score in zip(baseline_scores, candidate_scores):
        baseline_value = _unit_score(baseline_score)
        candidate_value = _unit_score(candidate_score)
        if baseline_value is None or candidate_value is None:
            invalid_pairs += 1
            continue
        deltas.append(candidate_value - baseline_value)

    n = len(deltas)
    if invalid_pairs:
        return _reject(
            (
                f"{invalid_pairs} paired score(s) are not finite real numbers in "
                "[0, 1]",
            ),
            n,
        )
    if n < _MIN_PAIRED_SAMPLES:
        return _reject(
            (
                f"at least {_MIN_PAIRED_SAMPLES} paired validation samples are "
                f"required, got {n}",
            ),
            n,
        )

    # -- the bound --------------------------------------------------------
    mean_delta = math.fsum(deltas) / n
    epsilon = math.sqrt(2.0 * math.log(1.0 / alpha_i) / n)
    lcb = mean_delta - epsilon
    delta_dl = max(0.0, candidate_dl - baseline_dl)
    penalty = lambda_value * delta_dl
    threshold = min_gain_value + penalty

    if not (math.isfinite(epsilon) and math.isfinite(lcb) and math.isfinite(threshold)):
        return _reject(
            ("the paired bound is not a finite number for these inputs",), n
        )

    summary = _summary(
        mean_delta=mean_delta,
        epsilon=epsilon,
        lcb=lcb,
        alpha_total=alpha_total_value,
        num_comparisons=num_comparisons,
        alpha_i=alpha_i,
        n=n,
        min_gain=min_gain_value,
        lambda_dl=lambda_value,
        delta_dl=delta_dl,
        penalty=penalty,
        threshold=threshold,
    )

    # -- the decision -----------------------------------------------------
    reasons: list[str] = []
    if not lcb > threshold:
        reasons.append(
            f"the lower confidence bound {_num(lcb)} does not exceed the required "
            f"gain {_num(threshold)}"
        )
    if not safety_checks_passed:
        reasons.append("safety checks did not pass")
    if not provenance_verified:
        reasons.append(
            "independence/provenance of the validation samples is not verified"
        )

    if reasons:
        return GateDecision(
            accepted=False,
            mean_delta=mean_delta,
            lower_confidence_bound=lcb,
            alpha=alpha_i,
            n=n,
            complexity_penalty=penalty,
            reasons=tuple(
                INCONCLUSIVE_PREFIX + reason + f" [{summary}]" for reason in reasons
            ),
        )

    return GateDecision(
        accepted=True,
        mean_delta=mean_delta,
        lower_confidence_bound=lcb,
        alpha=alpha_i,
        n=n,
        complexity_penalty=penalty,
        reasons=(
            ACCEPTED_PREFIX
            + "candidate cleared the acceptance bound on paired validation scores; "
            "this is evidence only and is not runtime approval"
            + f" [{summary}]",
        ),
    )
