"""Deterministic canonical JSON and SHA-256 helpers.

Canonical form is UTF-8 JSON with sorted object keys and the separators
``(",", ":")``. It exists so replay comparisons, memory hashes, and MDL
proxies are byte-reproducible. It is a deterministic engineering convention,
not a computation of Kolmogorov complexity.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from ..contracts import validate_json_value

__all__ = ["canonical_json", "canonical_bytes", "sha256_hex"]


def canonical_json(value: Any) -> str:
    """Return the canonical JSON text for a contract-approved JSON value."""
    validate_json_value(value)
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def canonical_bytes(value: Any) -> bytes:
    """Return canonical UTF-8 bytes for a contract-approved JSON value."""
    return canonical_json(value).encode("utf-8")


def sha256_hex(value_or_bytes: Any) -> str:
    """SHA-256 of raw bytes, or of the canonical JSON encoding of a value.

    A ``bytes`` argument is hashed verbatim; anything else is hashed as its
    canonical JSON encoding. The two are intentionally different inputs.
    """
    if isinstance(value_or_bytes, bytes):
        payload = value_or_bytes
    elif isinstance(value_or_bytes, (bytearray, memoryview)):
        raise TypeError("sha256_hex accepts bytes or JSON values, not " + type(value_or_bytes).__name__)
    else:
        payload = canonical_bytes(value_or_bytes)
    return hashlib.sha256(payload).hexdigest()
