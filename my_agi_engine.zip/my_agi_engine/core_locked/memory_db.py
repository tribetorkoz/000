"""Append-only SQLite episodic memory (``memory_db.py``).

This module is a small, auditable event store. It records explicit events and
never rewrites an earlier episode record. There is one table, one write path,
and no compaction, summarisation, or "memory edit" surface.

Tamper resistance, stated honestly
----------------------------------
The store enforces append-only behaviour with SQLite triggers that abort
``UPDATE`` and ``DELETE`` on ``events``. Those triggers stop mistakes and
ordinary application code. They are **not** tamper-proof: anyone who can open
the database file can drop the triggers, or use ``INSERT OR REPLACE`` on a
connection that has not enabled ``recursive_triggers``, which is the default
and which suppresses the implicit delete's trigger. The store enables
``recursive_triggers`` on its own connection as one extra layer, but that
pragma is per-connection and does not bind anyone else.

What actually protects the record is the hash chain: such edits are
*detectable* by :meth:`SQLiteMemoryStore.verify_chain` and by the verification
performed at open. Detection is not prevention, and truncating the newest
events is not detectable from the file alone -- that needs an external anchor
this module does not provide.

What this module deliberately does not do
-----------------------------------------
* It never stores prompts, request headers, credentials, or API keys. Callers
  own what they put in ``payload``; keeping secrets out of it is their duty.
* It never creates an LLM-written summary table, never replaces a row, never
  silently compacts or expires events, and never resets or deletes a database.
* It never creates parent directories. The configured database path is the only
  filesystem object it opens.
* It does not claim thread safety: one instance performs one operation at a
  time. Give each thread its own instance if you need concurrency; the
  ``BEGIN IMMEDIATE`` writer lock keeps separate instances from interleaving.

Chain format
------------
``previous_hash`` of the first event is :data:`GENESIS_PREVIOUS_HASH` (64
zeroes). Each event hash is the SHA-256 of the canonical JSON object containing
exactly ``sequence``, ``event_id``, ``event_type``, ``payload``,
``created_at``, and ``previous_hash`` -- everything except ``event_hash``.
``payload`` enters the hash as its parsed JSON value, and the stored text is the
canonical encoding of that same value, so the hash covers exactly the bytes on
disk.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable

from ..contracts import JSONValue, validate_json_value
from .canonical import canonical_json, sha256_hex

__all__ = [
    "GENESIS_PREVIOUS_HASH",
    "HASHED_FIELDS",
    "MAX_EVENT_TYPE_CHARS",
    "MAX_LIST_LIMIT",
    "MAX_PAYLOAD_BYTES",
    "SCHEMA_VERSION",
    "ChainVerification",
    "SQLiteMemoryStore",
    "MemoryStoreError",
    "InvalidEventTypeError",
    "InvalidPayloadError",
    "PayloadTooLargeError",
    "StoreClosedError",
    "SchemaIncompatibleError",
    "EventIdCollisionError",
    "ChainCorruptionError",
]

GENESIS_PREVIOUS_HASH = "0" * 64

#: Fields covered by ``event_hash``, in documented order. ``event_hash`` is the
#: only column excluded.
HASHED_FIELDS = (
    "sequence",
    "event_id",
    "event_type",
    "payload",
    "created_at",
    "previous_hash",
)

#: Columns returned by :meth:`SQLiteMemoryStore.list_events`.
EVENT_FIELDS = HASHED_FIELDS + ("event_hash",)

MAX_PAYLOAD_BYTES = 256 * 1024
MAX_EVENT_TYPE_CHARS = 128
MAX_LIST_LIMIT = 10_000

#: Current schema version, stored in ``PRAGMA user_version``. Migrations are
#: forward-only and additive; a newer or unrecognised version stops the store.
SCHEMA_VERSION = 1

_CREATE_EVENTS = """
CREATE TABLE IF NOT EXISTS events (
    sequence      INTEGER PRIMARY KEY CHECK (sequence >= 1),
    event_id      TEXT    NOT NULL UNIQUE,
    event_type    TEXT    NOT NULL,
    payload       TEXT    NOT NULL,
    created_at    TEXT    NOT NULL,
    previous_hash TEXT    NOT NULL CHECK (length(previous_hash) = 64),
    event_hash    TEXT    NOT NULL CHECK (length(event_hash) = 64)
)
"""

_CREATE_EVENTS_INDEX = (
    "CREATE INDEX IF NOT EXISTS events_event_type_sequence "
    "ON events (event_type, sequence)"
)

_CREATE_BLOCK_UPDATE = """
CREATE TRIGGER IF NOT EXISTS events_block_update
BEFORE UPDATE ON events
BEGIN
    SELECT RAISE(ABORT, 'append_only: UPDATE on events is not allowed');
END
"""

_CREATE_BLOCK_DELETE = """
CREATE TRIGGER IF NOT EXISTS events_block_delete
BEFORE DELETE ON events
BEGIN
    SELECT RAISE(ABORT, 'append_only: DELETE on events is not allowed');
END
"""

_SELECT_EVENT = (
    "SELECT sequence, event_id, event_type, payload, created_at, "
    "previous_hash, event_hash FROM events"
)

_TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"


# --------------------------------------------------------------------------
# Errors
# --------------------------------------------------------------------------


class MemoryStoreError(Exception):
    """Base class for stable, caller-facing memory store failures."""


class StoreClosedError(MemoryStoreError):
    """The store was used after :meth:`SQLiteMemoryStore.close`."""


class InvalidEventTypeError(MemoryStoreError):
    """``event_type`` is not a bare, bounded identifier."""


class InvalidPayloadError(MemoryStoreError):
    """``payload`` is not a contract-approved JSON value."""


class PayloadTooLargeError(MemoryStoreError):
    """The canonical payload exceeds the 256 KiB cap."""


class SchemaIncompatibleError(MemoryStoreError):
    """The database file is not ours, is newer, or has an unknown layout."""


class EventIdCollisionError(MemoryStoreError):
    """A generated ``event_id`` already exists; nothing was written."""


class ChainCorruptionError(MemoryStoreError):
    """The stored chain failed verification, so writes are refused."""

    def __init__(self, detail: str) -> None:
        super().__init__(detail)
        self.detail = detail


@dataclass(frozen=True, slots=True)
class ChainVerification:
    """Result of one chain verification pass. Never contains payload data."""

    ok: bool
    checked: int
    bad_sequence: int | None = None
    detail: str | None = None


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).strftime(_TIMESTAMP_FORMAT)


def _validate_timestamp(value: object) -> str:
    if not isinstance(value, str):
        raise MemoryStoreError("created_at source must return str")
    try:
        datetime.strptime(value, _TIMESTAMP_FORMAT)
    except ValueError as exc:
        raise MemoryStoreError("created_at source must return UTC ISO-8601") from exc
    return value


def _validate_event_type(event_type: object) -> str:
    if not isinstance(event_type, str):
        raise InvalidEventTypeError("event_type must be str")
    if not event_type:
        raise InvalidEventTypeError("event_type must not be empty")
    if len(event_type) > MAX_EVENT_TYPE_CHARS:
        raise InvalidEventTypeError(
            f"event_type must be at most {MAX_EVENT_TYPE_CHARS} characters"
        )
    if event_type != event_type.strip():
        raise InvalidEventTypeError("event_type must not have surrounding whitespace")
    if any(ord(char) < 0x20 or ord(char) == 0x7F for char in event_type):
        raise InvalidEventTypeError("event_type must not contain control characters")
    try:
        event_type.encode("utf-8")
    except UnicodeEncodeError as exc:
        # Would otherwise surface later as a UnicodeEncodeError from the driver.
        raise InvalidEventTypeError(
            "event_type must be encodable as UTF-8"
        ) from exc
    return event_type


def _encode_payload(payload: object) -> tuple[str, Any]:
    """Validate, cap, and canonically encode a payload.

    Returns the stored text and the parsed value that text decodes to, so the
    caller hashes exactly what is persisted rather than a live object the
    caller still holds a reference to.
    """
    try:
        validate_json_value(payload, path="$payload")
    except (TypeError, ValueError) as exc:
        raise InvalidPayloadError(
            "payload must be a contract-approved JSON value"
        ) from exc
    try:
        encoded = canonical_json(payload)
        encoded_bytes = encoded.encode("utf-8")
    except UnicodeEncodeError as exc:
        # A lone surrogate survives json.dumps but cannot be stored as UTF-8.
        raise InvalidPayloadError(
            "payload contains text that is not encodable as UTF-8"
        ) from exc
    except (TypeError, ValueError) as exc:
        raise InvalidPayloadError("payload is not canonically encodable") from exc
    if len(encoded_bytes) > MAX_PAYLOAD_BYTES:
        raise PayloadTooLargeError(
            f"canonical payload exceeds {MAX_PAYLOAD_BYTES} bytes"
        )
    return encoded, json.loads(encoded)


def _event_hash(
    sequence: int,
    event_id: str,
    event_type: str,
    payload: Any,
    created_at: str,
    previous_hash: str,
) -> str:
    record = {
        "sequence": sequence,
        "event_id": event_id,
        "event_type": event_type,
        "payload": payload,
        "created_at": created_at,
        "previous_hash": previous_hash,
    }
    return sha256_hex(record)


def _rollback(conn: sqlite3.Connection) -> None:
    if conn.in_transaction:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:  # pragma: no cover - rollback is best effort
            pass


def _row_to_event(row: sqlite3.Row) -> dict[str, Any]:
    sequence = int(row["sequence"])
    try:
        payload = json.loads(row["payload"])
    except (TypeError, ValueError) as exc:
        raise ChainCorruptionError(
            f"payload is not valid JSON at sequence {sequence}"
        ) from exc
    return {
        "sequence": sequence,
        "event_id": row["event_id"],
        "event_type": row["event_type"],
        "payload": payload,
        "created_at": row["created_at"],
        "previous_hash": row["previous_hash"],
        "event_hash": row["event_hash"],
    }


# --------------------------------------------------------------------------
# Store
# --------------------------------------------------------------------------


class SQLiteMemoryStore:
    """Append-only event log satisfying :class:`~my_agi_engine.contracts.MemoryStore`."""

    __slots__ = ("_path", "_conn", "_now", "_chain_error", "_closed")

    def __init__(
        self,
        path: str,
        *,
        now: Callable[[], str] | None = None,
    ) -> None:
        if not isinstance(path, str):
            raise TypeError("path must be str")
        if not path:
            raise MemoryStoreError("path must be non-empty")
        if "\x00" in path:
            raise MemoryStoreError("path must not contain NUL")

        self._path = path
        self._now = now if now is not None else _utc_timestamp
        self._chain_error: ChainVerification | None = None
        self._closed = False

        try:
            # uri=False keeps "file:"-prefixed paths literal instead of letting
            # a caller smuggle in SQLite URI open modes.
            conn = sqlite3.connect(path, isolation_level=None, timeout=5.0, uri=False)
        except sqlite3.Error as exc:
            raise MemoryStoreError("database could not be opened") from exc
        conn.row_factory = sqlite3.Row
        self._conn = conn

        try:
            self._prepare_connection()
            self._ensure_schema()
        except BaseException:
            try:
                conn.close()
            finally:
                self._closed = True
            raise

        # Verify once at open, but report rather than raise: an operator may
        # still need to read a corrupt store to diagnose it. Writes are refused
        # from here on until a later verification passes.
        self.verify_chain()

    # -- lifecycle ---------------------------------------------------------

    def close(self) -> None:
        """Close the connection. Idempotent; never deletes the database."""
        if self._closed:
            return
        self._closed = True
        try:
            self._conn.close()
        except sqlite3.Error:  # pragma: no cover - close is best effort
            pass

    @property
    def closed(self) -> bool:
        return self._closed

    @property
    def path(self) -> str:
        return self._path

    @property
    def is_healthy(self) -> bool:
        """True when the last verification pass found an intact chain."""
        return self._chain_error is None

    def __enter__(self) -> "SQLiteMemoryStore":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    def __repr__(self) -> str:
        state = "closed" if self._closed else ("healthy" if self.is_healthy else "corrupt")
        return f"<SQLiteMemoryStore path={self._path!r} state={state}>"

    # -- MemoryStore -------------------------------------------------------

    def append_event(self, event_type: str, payload: JSONValue) -> str:
        """Append one event and return its generated ``event_id``.

        The caller cannot choose the id, the sequence, the timestamp, or the
        hashes. All of them are allocated here, in one ``BEGIN IMMEDIATE``
        transaction, so concurrent writers cannot mint the same sequence.
        """
        self._require_open()
        if self._chain_error is not None:
            raise ChainCorruptionError(self._chain_error.detail or "chain is corrupt")
        _validate_event_type(event_type)
        encoded, stored_payload = _encode_payload(payload)
        created_at = _validate_timestamp(self._now())
        event_id = uuid.uuid4().hex

        conn = self._conn
        try:
            conn.execute("BEGIN IMMEDIATE")
        except sqlite3.Error as exc:
            raise MemoryStoreError("write transaction could not be started") from exc

        try:
            sequence, previous_hash = self._prepare_append(conn)
            event_hash = _event_hash(
                sequence,
                event_id,
                event_type,
                stored_payload,
                created_at,
                previous_hash,
            )
            # Single insert: there is no insert-then-update window, because the
            # UPDATE trigger would (correctly) abort the second statement.
            conn.execute(
                "INSERT INTO events "
                "(sequence, event_id, event_type, payload, created_at, "
                "previous_hash, event_hash) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    sequence,
                    event_id,
                    event_type,
                    encoded,
                    created_at,
                    previous_hash,
                    event_hash,
                ),
            )
            conn.execute("COMMIT")
        except sqlite3.IntegrityError as exc:
            _rollback(conn)
            message = str(exc).lower()
            if "event_id" in message or "unique" in message:
                raise EventIdCollisionError(
                    "generated event_id already exists; nothing was written"
                ) from exc
            raise MemoryStoreError("event rejected by store constraints") from exc
        except sqlite3.Error as exc:
            _rollback(conn)
            raise MemoryStoreError("event could not be appended") from exc
        except BaseException:
            _rollback(conn)
            raise

        return event_id

    def list_events(
        self, event_type: str | None = None, limit: int = 100
    ) -> list[JSONValue]:
        """Return events ordered by ascending ``sequence``.

        ``event_type`` filters by exact match; ``None`` returns every type.
        ``limit`` caps the number of rows and must be a positive integer.
        """
        self._require_open()
        if isinstance(limit, bool) or not isinstance(limit, int):
            raise TypeError("limit must be int")
        if limit < 1:
            raise ValueError("limit must be >= 1")
        if limit > MAX_LIST_LIMIT:
            raise ValueError(f"limit must be <= {MAX_LIST_LIMIT}")
        if event_type is not None:
            _validate_event_type(event_type)

        if event_type is None:
            rows = self._conn.execute(
                _SELECT_EVENT + " ORDER BY sequence ASC LIMIT ?",
                (limit,),
            ).fetchall()
        else:
            rows = self._conn.execute(
                _SELECT_EVENT
                + " WHERE event_type = ? ORDER BY sequence ASC LIMIT ?",
                (event_type, limit),
            ).fetchall()
        return [_row_to_event(row) for row in rows]

    # -- verification ------------------------------------------------------

    def verify_chain(self) -> ChainVerification:
        """Walk the whole chain and report the first defect found.

        A failure also blocks subsequent appends until a later pass succeeds,
        so a store that has noticed corruption cannot extend it.
        """
        self._require_open()
        try:
            rows = self._conn.execute(
                _SELECT_EVENT + " ORDER BY sequence ASC"
            ).fetchall()
        except sqlite3.Error:
            return self._record(
                ChainVerification(
                    False, 0, None, "events table could not be read"
                )
            )

        expected_previous = GENESIS_PREVIOUS_HASH
        expected_sequence = 1
        checked = 0
        for row in rows:
            sequence = int(row["sequence"])
            if sequence != expected_sequence:
                return self._record(
                    ChainVerification(
                        False,
                        checked,
                        sequence,
                        f"missing or out-of-order sequence at {sequence}",
                    )
                )
            try:
                payload = json.loads(row["payload"])
            except (TypeError, ValueError):
                return self._record(
                    ChainVerification(
                        False,
                        checked,
                        sequence,
                        f"payload is not valid JSON at sequence {sequence}",
                    )
                )
            try:
                recomputed = _event_hash(
                    sequence,
                    row["event_id"],
                    row["event_type"],
                    payload,
                    row["created_at"],
                    row["previous_hash"],
                )
            except (TypeError, ValueError):
                return self._record(
                    ChainVerification(
                        False,
                        checked,
                        sequence,
                        f"event fields are not hashable JSON at sequence {sequence}",
                    )
                )
            if row["previous_hash"] != expected_previous:
                return self._record(
                    ChainVerification(
                        False, checked, sequence, f"broken link at sequence {sequence}"
                    )
                )
            if recomputed != row["event_hash"]:
                return self._record(
                    ChainVerification(
                        False, checked, sequence, f"hash mismatch at sequence {sequence}"
                    )
                )
            expected_previous = row["event_hash"]
            expected_sequence += 1
            checked += 1

        return self._record(ChainVerification(True, checked))

    # -- internals ---------------------------------------------------------

    def _record(self, verification: ChainVerification) -> ChainVerification:
        self._chain_error = None if verification.ok else verification
        return verification

    def _require_open(self) -> None:
        if self._closed:
            raise StoreClosedError("memory store is closed")

    def _prepare_connection(self) -> None:
        conn = self._conn
        try:
            # REPLACE implements its conflict delete without firing DELETE
            # triggers unless recursive triggers are on; turn them on so an
            # INSERT OR REPLACE cannot quietly overwrite an event row.
            conn.execute("PRAGMA recursive_triggers = ON")
        except sqlite3.Error as exc:
            raise MemoryStoreError("database could not be configured") from exc

    def _ensure_schema(self) -> None:
        conn = self._conn
        try:
            version = int(conn.execute("PRAGMA user_version").fetchone()[0])
        except (sqlite3.Error, TypeError, ValueError) as exc:
            raise SchemaIncompatibleError(
                "existing file is not a usable SQLite database"
            ) from exc

        if version > SCHEMA_VERSION:
            raise SchemaIncompatibleError(
                f"database schema version {version} is newer than {SCHEMA_VERSION}"
            )

        if version == SCHEMA_VERSION:
            self._require_expected_columns()
            self._ensure_guards()
            return

        # version is 0: either a brand new file, or an unversioned table from
        # an earlier draft of this module. Adopt only an exactly matching
        # layout; anything else stops instead of being migrated destructively.
        try:
            existing = conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'events'"
            ).fetchone()
        except sqlite3.Error as exc:
            raise SchemaIncompatibleError(
                "existing file is not a usable SQLite database"
            ) from exc

        if existing is not None:
            self._require_expected_columns()

        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(_CREATE_EVENTS)
            conn.execute(_CREATE_EVENTS_INDEX)
            conn.execute(_CREATE_BLOCK_UPDATE)
            conn.execute(_CREATE_BLOCK_DELETE)
            conn.execute(f"PRAGMA user_version = {int(SCHEMA_VERSION)}")
            conn.execute("COMMIT")
        except sqlite3.Error as exc:
            _rollback(conn)
            raise SchemaIncompatibleError(
                "database schema could not be created"
            ) from exc

    def _require_expected_columns(self) -> None:
        try:
            rows = self._conn.execute("PRAGMA table_info(events)").fetchall()
        except sqlite3.Error as exc:
            raise SchemaIncompatibleError("events table could not be inspected") from exc
        if not rows:
            raise SchemaIncompatibleError("events table is missing")
        actual = tuple(str(row["name"]) for row in rows)
        if actual != EVENT_FIELDS:
            raise SchemaIncompatibleError(
                "events table layout is not the versioned layout"
            )

    def _ensure_guards(self) -> None:
        try:
            self._conn.execute(_CREATE_BLOCK_UPDATE)
            self._conn.execute(_CREATE_BLOCK_DELETE)
        except sqlite3.Error as exc:
            raise SchemaIncompatibleError(
                "append-only guards could not be ensured"
            ) from exc

    def _prepare_append(self, conn: sqlite3.Connection) -> tuple[int, str]:
        tail = conn.execute(
            _SELECT_EVENT + " ORDER BY sequence DESC LIMIT 1"
        ).fetchone()
        if tail is None:
            return 1, GENESIS_PREVIOUS_HASH

        sequence = int(tail["sequence"])
        try:
            tail_payload = json.loads(tail["payload"])
        except (TypeError, ValueError) as exc:
            raise ChainCorruptionError(
                f"payload is not valid JSON at sequence {sequence}"
            ) from exc
        try:
            recomputed = _event_hash(
                sequence,
                tail["event_id"],
                tail["event_type"],
                tail_payload,
                tail["created_at"],
                tail["previous_hash"],
            )
        except (TypeError, ValueError) as exc:
            raise ChainCorruptionError(
                f"event fields are not hashable JSON at sequence {sequence}"
            ) from exc
        if recomputed != tail["event_hash"]:
            raise ChainCorruptionError(f"hash mismatch at sequence {sequence}")
        return sequence + 1, str(tail["event_hash"])
