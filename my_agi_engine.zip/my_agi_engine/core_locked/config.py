"""Validated, deterministic engine configuration.

Only six environment keys are authorised. Model URL/key/name may be absent,
which means "remote model unavailable" -- never a guessed provider. Loading
configuration opens no database, reads no file, and contacts no network.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass, field
from typing import Mapping
from urllib.parse import urlsplit

__all__ = ["DEFAULT_SQLITE_PATH", "DEFAULT_MODEL_TIMEOUT_SECONDS", "MAX_MODEL_TIMEOUT_SECONDS", "EngineConfig"]

DEFAULT_SQLITE_PATH = "./data/agi_memory.sqlite3"
DEFAULT_MODEL_TIMEOUT_SECONDS = 20.0
MAX_MODEL_TIMEOUT_SECONDS = 30.0

_ENV_KEYS = (
    "AGI_SQLITE_PATH",
    "AGI_MODEL_BASE_URL",
    "AGI_MODEL_API_KEY",
    "AGI_MODEL_PRIMARY",
    "AGI_MODEL_ESCALATION",
    "AGI_MODEL_TIMEOUT_SECONDS",
)


@dataclass(frozen=True, slots=True)
class EngineConfig:
    """Immutable configuration snapshot for one process.

    The API key is excluded from ``repr`` so it cannot leak through logging,
    exception formatting, or test output.
    """

    sqlite_path: str = DEFAULT_SQLITE_PATH
    model_base_url: str | None = None
    model_api_key: str | None = field(default=None, repr=False)
    model_primary: str | None = None
    model_escalation: str | None = None
    model_timeout_seconds: float = DEFAULT_MODEL_TIMEOUT_SECONDS

    def __post_init__(self) -> None:
        _validate_path(self.sqlite_path)
        for name in ("model_base_url", "model_primary", "model_escalation"):
            value = getattr(self, name)
            if value is not None:
                if not isinstance(value, str):
                    raise TypeError(f"{name} must be str or None")
                if not value:
                    raise ValueError(f"{name} must be non-empty when set")
        if self.model_api_key is not None:
            if not isinstance(self.model_api_key, str):
                raise TypeError("model_api_key must be str or None")
            if not self.model_api_key:
                raise ValueError("model_api_key must be non-empty when set")
        if self.model_base_url is not None:
            _validate_base_url(self.model_base_url)
        timeout = self.model_timeout_seconds
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
            raise TypeError("model_timeout_seconds must be a real number")
        number = float(timeout)
        if not math.isfinite(number):
            raise ValueError("model_timeout_seconds must be finite")
        if number <= 0.0 or number > MAX_MODEL_TIMEOUT_SECONDS:
            raise ValueError(
                f"model_timeout_seconds must be > 0 and <= {MAX_MODEL_TIMEOUT_SECONDS:g}"
            )
        object.__setattr__(self, "model_timeout_seconds", number)

    @property
    def is_model_configured(self) -> bool:
        """True only when an endpoint and at least one model name are present."""
        return bool(self.model_base_url) and bool(self.model_primary or self.model_escalation)

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None) -> "EngineConfig":
        """Build configuration from the six authorised keys only.

        Unknown keys are ignored. No value is echoed in an error message.
        """
        source: Mapping[str, str] = os.environ if environ is None else environ
        sqlite_path = _optional(source, "AGI_SQLITE_PATH") or DEFAULT_SQLITE_PATH
        base_url = _optional(source, "AGI_MODEL_BASE_URL")
        api_key = _optional(source, "AGI_MODEL_API_KEY")
        primary = _optional(source, "AGI_MODEL_PRIMARY")
        escalation = _optional(source, "AGI_MODEL_ESCALATION")
        raw_timeout = _optional(source, "AGI_MODEL_TIMEOUT_SECONDS")
        if raw_timeout is None:
            timeout = DEFAULT_MODEL_TIMEOUT_SECONDS
        else:
            try:
                timeout = float(raw_timeout)
            except (TypeError, ValueError) as exc:
                raise ValueError("AGI_MODEL_TIMEOUT_SECONDS must be a decimal number") from exc
        return cls(
            sqlite_path=sqlite_path,
            model_base_url=base_url,
            model_api_key=api_key,
            model_primary=primary,
            model_escalation=escalation,
            model_timeout_seconds=timeout,
        )


def _optional(environ: Mapping[str, str], key: str) -> str | None:
    if key not in environ:
        return None
    value = environ[key]
    if not isinstance(value, str):
        raise TypeError(f"{key} must be a string")
    stripped = value.strip()
    if not stripped:
        raise ValueError(f"{key} is set but empty")
    return stripped


def _validate_path(path: object) -> None:
    if not isinstance(path, str):
        raise TypeError("sqlite_path must be str")
    if not path:
        raise ValueError("sqlite_path must be non-empty")
    if "\x00" in path:
        raise ValueError("sqlite_path must not contain NUL")


def _validate_base_url(url: str) -> None:
    try:
        parts = urlsplit(url)
    except ValueError as exc:
        raise ValueError("model_base_url is not a parseable URL") from exc
    scheme = parts.scheme.lower()
    if scheme not in ("http", "https"):
        raise ValueError("model_base_url must use http or https")
    if not parts.netloc:
        raise ValueError("model_base_url must include a host")
    if scheme == "http" and parts.hostname not in ("127.0.0.1", "::1", "localhost"):
        raise ValueError("plain http model_base_url is allowed only for loopback hosts")
