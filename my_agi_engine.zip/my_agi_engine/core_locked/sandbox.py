"""Locked skill execution boundary (``sandbox.py``).

This module is one stable façade over :mod:`ast_guard` and
:mod:`interpreter`. It is a **capability-restricted interpreter boundary**:
skill source can only compute with JSON values and approved pure builtins,
and can only call skills that a host-supplied resolver returns.

It is **not** isolation from arbitrary native code and **not** an OS-level
sandbox. It does not protect against bugs in CPython itself, and it makes no
claim of "full security". If a requirement ever needs general Python
execution, it needs a separately approved OS-isolation design, not a wider
allowlist here.

Allowed effects inside a skill: the interpreter's JSON computation and calls
to resolver-provided skills. There is no filesystem, network, process,
import, or bytecode-compilation capability on this path.

Stable error codes: ``INVALID_ARTIFACT``, ``INVALID_BUDGET``,
``SOURCE_TOO_LARGE``, ``INVALID_PAYLOAD``, ``PAYLOAD_TOO_LARGE``,
``UNAPPROVED_DEPENDENCY``, ``DEPENDENCY_CYCLE``, ``DEPENDENCY_TOO_DEEP``,
``INTERNAL_ERROR``; plus the codes propagated from the interpreter.
"""

from __future__ import annotations

from typing import Callable

from ..contracts import (
    Budget,
    ExecutionResult,
    JSONValue,
    RunStatus,
    SkillArtifact,
    SkillResolver,
    validate_json_value,
)
from .canonical import canonical_json
from .interpreter import interpret_skill

__all__ = ["RestrictedSkillExecutor", "MAX_DEPENDENCY_DEPTH"]

MAX_DEPENDENCY_DEPTH = 8


def _blocked(code: str, steps: int = 0, elapsed_ms: int = 0) -> ExecutionResult:
    return ExecutionResult(RunStatus.BLOCKED, None, steps, elapsed_ms, code)


class RestrictedSkillExecutor:
    """Concrete ``SkillExecutor`` that only ever reaches the interpreter."""

    __slots__ = ("_clock",)

    def __init__(self, *, clock: Callable[[], float] | None = None) -> None:
        self._clock = clock

    def execute(
        self,
        skill: SkillArtifact,
        payload: JSONValue,
        budget: Budget,
        resolver: SkillResolver | None = None,
    ) -> ExecutionResult:
        if not isinstance(budget, Budget):
            return _blocked("INVALID_BUDGET")
        if not isinstance(skill, SkillArtifact):
            return _blocked("INVALID_ARTIFACT")
        if not isinstance(skill.source, str) or not skill.source:
            return _blocked("INVALID_ARTIFACT")
        try:
            source_bytes = skill.source.encode("utf-8")
        except UnicodeEncodeError:
            return _blocked("INVALID_ARTIFACT")
        if len(source_bytes) > budget.max_artifact_bytes:
            return _blocked("SOURCE_TOO_LARGE")

        try:
            validate_json_value(payload, path="$payload")
        except (TypeError, ValueError):
            return _blocked("INVALID_PAYLOAD")
        try:
            encoded_payload = canonical_json(payload).encode("utf-8")
        except (TypeError, ValueError):
            return _blocked("INVALID_PAYLOAD")
        if len(encoded_payload) > budget.max_payload_bytes:
            return _blocked("PAYLOAD_TOO_LARGE")

        dependency_error = self._check_dependencies(skill, resolver)
        if dependency_error is not None:
            return _blocked(dependency_error)

        try:
            return interpret_skill(
                skill.source,
                payload,
                budget,
                resolver,
                clock=self._clock,
            )
        except Exception:  # noqa: BLE001 - never surface a traceback or source
            return _blocked("INTERNAL_ERROR")

    def _check_dependencies(
        self, skill: SkillArtifact, resolver: SkillResolver | None
    ) -> str | None:
        """Validate the declared dependency closure without executing it.

        A cycle, an over-deep closure, or an unresolvable dependency fails
        closed. Diamond dependencies are permitted; only a repeated node on
        the current path is a cycle.
        """
        if not skill.depends_on:
            return None
        if resolver is None:
            return "UNAPPROVED_DEPENDENCY"
        validated: dict[str, SkillArtifact] = {}

        def walk(skill_id: str, path: tuple[str, ...]) -> str | None:
            if skill_id in path:
                return "DEPENDENCY_CYCLE"
            if len(path) >= MAX_DEPENDENCY_DEPTH:
                return "DEPENDENCY_TOO_DEEP"
            if skill_id in validated:
                return None
            artifact = resolver.get_approved(skill_id)
            if not isinstance(artifact, SkillArtifact):
                return "UNAPPROVED_DEPENDENCY"
            if artifact.skill_id != skill_id:
                # A resolver that hands back a different skill than the one
                # requested has not approved this dependency.
                return "UNAPPROVED_DEPENDENCY"
            validated[skill_id] = artifact
            for dependency in artifact.depends_on:
                if dependency == skill.skill_id:
                    return "DEPENDENCY_CYCLE"
                error = walk(dependency, path + (skill_id,))
                if error is not None:
                    return error
            return None

        for dependency in skill.depends_on:
            error = walk(dependency, ())
            if error is not None:
                return error
        return None

