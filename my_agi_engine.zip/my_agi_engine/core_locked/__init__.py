"""Safety-critical modules that are read-only at runtime.

Configuration/canonicalization, the AST guard, the restricted interpreter
boundary, append-only memory, and the statistical gate live here. The
runtime agent never edits this package; changes require a human-controlled
review outside any run.
"""
