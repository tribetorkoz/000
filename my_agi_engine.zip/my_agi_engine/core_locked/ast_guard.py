"""Fail-closed syntax and capability validation for model-proposed skills.

This module never executes code. It parses source text with :func:`ast.parse`
and accepts exactly one grammar shape: a single top-level
``def solve(data): ...`` built from a small expression/statement allowlist.

The guard is a filter, not a sandbox. The restricted interpreter validates
again and is the component that bounds execution.

Rejection codes are stable machine-readable tokens so tests and callers can
branch on them without parsing prose. Codes never embed source text or user
data.
"""

from __future__ import annotations

import ast
import re

from ..contracts import JSONValue

__all__ = [
    "GuardResult",
    "validate_skill_source",
    "PURE_BUILTINS",
    "MAX_SOURCE_BYTES",
    "MAX_NODES",
    "MAX_DEPTH",
    "SKILL_ID_PATTERN",
]

MAX_SOURCE_BYTES = 32768
MAX_NODES = 500
MAX_DEPTH = 32
SKILL_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")

PURE_BUILTINS = frozenset({"len", "min", "max", "sum", "sorted", "abs", "round", "range"})
_RESERVED_NAMES = PURE_BUILTINS | frozenset({"call_skill", "solve", "__import__"})

_ALLOWED_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.FloorDiv, ast.Mod)
_ALLOWED_UNARYOPS = (ast.USub, ast.UAdd, ast.Not)
_ALLOWED_BOOLOPS = (ast.And, ast.Or)
_ALLOWED_CMPOPS = (ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE)

_SPECIFIC_STATEMENT_CODES = {
    ast.While: "E_WHILE",
    ast.Import: "E_IMPORT",
    ast.ImportFrom: "E_IMPORT",
    ast.ClassDef: "E_CLASS",
    ast.Try: "E_TRY",
    ast.With: "E_WITH",
    ast.AsyncWith: "E_WITH",
    ast.AsyncFor: "E_ASYNC",
    ast.AsyncFunctionDef: "E_NESTED_DEF",
    ast.FunctionDef: "E_NESTED_DEF",
    ast.Lambda: "E_LAMBDA",
    ast.Global: "E_GLOBAL",
    ast.Nonlocal: "E_NONLOCAL",
    ast.Delete: "E_DELETE",
    ast.Raise: "E_RAISE",
    ast.Assert: "E_ASSERT",
    ast.Break: "E_BREAK",
    ast.Continue: "E_CONTINUE",
    ast.Pass: "E_PASS",
    ast.Match: "E_MATCH",
    ast.TypeAlias: "E_STATEMENT",
}

_SPECIFIC_EXPRESSION_CODES = {
    ast.Attribute: "E_ATTRIBUTE",
    ast.Lambda: "E_LAMBDA",
    ast.ListComp: "E_COMPREHENSION",
    ast.SetComp: "E_COMPREHENSION",
    ast.DictComp: "E_COMPREHENSION",
    ast.GeneratorExp: "E_COMPREHENSION",
    ast.JoinedStr: "E_FSTRING",
    ast.FormattedValue: "E_FSTRING",
    ast.NamedExpr: "E_WALRUS",
    ast.Await: "E_AWAIT",
    ast.Yield: "E_YIELD",
    ast.YieldFrom: "E_YIELD",
    ast.Starred: "E_STARRED",
    ast.Set: "E_EXPRESSION",
    ast.SetComp: "E_COMPREHENSION",
    ast.Import: "E_IMPORT",
}


class _Reject(Exception):
    """Internal control-flow signal carrying one stable rejection code."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class GuardResult:
    """Result of validation.

    ``accepted`` is True only for a fully validated module; ``module`` is the
    parsed (never executed) tree in that case, otherwise ``None``. ``codes``
    is empty on acceptance and holds exactly one stable code on rejection.
    """

    __slots__ = ("accepted", "module", "codes")

    def __init__(self, accepted: bool, module: ast.Module | None, codes: tuple[str, ...]) -> None:
        self.accepted = accepted
        self.module = module
        self.codes = codes

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, GuardResult):
            return NotImplemented
        return (self.accepted, self.codes) == (other.accepted, other.codes)

    def __repr__(self) -> str:  # never prints source text
        return f"GuardResult(accepted={self.accepted!r}, codes={self.codes!r})"


def validate_skill_source(source: str, *, max_source_bytes: int = MAX_SOURCE_BYTES) -> GuardResult:
    """Validate skill source against the frozen grammar.

    Returns a :class:`GuardResult`. Never executes, imports, or compiles the
    source. Unknown syntax fails closed with a stable rejection code.
    """
    try:
        module = _validate(source, max_source_bytes)
    except _Reject as reject:
        return GuardResult(False, None, (reject.code,))
    return GuardResult(True, module, ())


def _validate(source: JSONValue, max_source_bytes: int) -> ast.Module:
    if not isinstance(source, str):
        raise _Reject("E_SOURCE_TYPE")
    if not isinstance(max_source_bytes, int) or isinstance(max_source_bytes, bool) or max_source_bytes <= 0:
        raise _Reject("E_LIMIT")
    try:
        encoded = source.encode("utf-8")
    except UnicodeEncodeError as exc:  # lone surrogates cannot be UTF-8 source
        raise _Reject("E_SOURCE_UTF8") from exc
    if len(encoded) > max_source_bytes:
        raise _Reject("E_SOURCE_BYTES")
    try:
        module = ast.parse(source, mode="exec")
    except (SyntaxError, ValueError, MemoryError, RecursionError) as exc:
        raise _Reject("E_SYNTAX") from exc

    count, depth = _measure(module)
    if count > MAX_NODES:
        raise _Reject("E_NODE_COUNT")
    if depth > MAX_DEPTH:
        raise _Reject("E_DEPTH")

    if len(module.body) != 1 or not isinstance(module.body[0], ast.FunctionDef):
        raise _Reject("E_TOP_LEVEL")
    function = module.body[0]
    _check_signature(function)

    checker = _Checker()
    for statement in function.body:
        checker.statement(statement)
    return module


def _measure(node: ast.AST) -> tuple[int, int]:
    """Count nodes and tree height without recursing.

    The walk must be iterative. Source such as ``1+1+1+...`` parses into a long
    left-nested ``BinOp`` chain; a recursive walk would raise ``RecursionError``
    on valid input instead of returning a stable ``E_*`` rejection, and this
    guard is called before the interpreter's exception handling exists.
    """
    count = 0
    deepest = 0
    stack: list[tuple[ast.AST, int]] = [(node, 1)]
    while stack:
        current, depth = stack.pop()
        count += 1
        if depth > deepest:
            deepest = depth
        for child in ast.iter_child_nodes(current):
            stack.append((child, depth + 1))
    return count, deepest


def _check_signature(function: ast.FunctionDef) -> None:
    if function.name != "solve":
        raise _Reject("E_FUNCTION_NAME")
    if function.decorator_list:
        raise _Reject("E_DECORATOR")
    if function.returns is not None:
        raise _Reject("E_ANNOTATION")
    arguments = function.args
    if arguments.posonlyargs or arguments.kwonlyargs or arguments.vararg or arguments.kwarg:
        raise _Reject("E_PARAMS")
    if arguments.defaults or arguments.kw_defaults:
        raise _Reject("E_PARAMS")
    if len(arguments.args) != 1 or arguments.args[0].arg != "data":
        raise _Reject("E_PARAMS")
    if arguments.args[0].annotation is not None:
        raise _Reject("E_ANNOTATION")
    if not function.body:
        raise _Reject("E_STATEMENT")


class _Checker:
    """Recursive allowlist walker. Raises ``_Reject`` on the first violation."""

    def statement(self, node: ast.stmt) -> None:
        specific = _SPECIFIC_STATEMENT_CODES.get(type(node))
        if specific is not None:
            raise _Reject(specific)
        if isinstance(node, ast.Assign):
            if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
                raise _Reject("E_STATEMENT")
            self._bind(node.targets[0])
            self.expression(node.value)
            return
        if isinstance(node, ast.If):
            self.expression(node.test)
            for child in node.body:
                self.statement(child)
            for child in node.orelse:
                self.statement(child)
            return
        if isinstance(node, ast.For):
            if node.orelse:
                raise _Reject("E_STATEMENT")
            if not isinstance(node.target, ast.Name):
                raise _Reject("E_STATEMENT")
            self._bind(node.target)
            call = node.iter
            if not isinstance(call, ast.Call) or not _is_name(call.func, "range"):
                raise _Reject("E_STATEMENT")
            for argument in call.args:
                self.expression(argument)
            if call.keywords:
                raise _Reject("E_KEYWORDS")
            for child in node.body:
                self.statement(child)
            return
        if isinstance(node, ast.Expr):
            self.expression(node.value)
            return
        if isinstance(node, ast.Return):
            if node.value is not None:
                self.expression(node.value)
            return
        raise _Reject("E_STATEMENT")

    def _bind(self, target: ast.Name) -> None:
        self.name(target.id, binding=True)

    def name(self, identifier: str, *, binding: bool = False) -> None:
        if not identifier.isidentifier():
            raise _Reject("E_NAME")
        if identifier.startswith("_"):
            raise _Reject("E_NAME")
        if identifier in _RESERVED_NAMES:
            raise _Reject("E_SHADOW" if binding else "E_NAME")

    def expression(self, node: ast.expr) -> None:
        specific = _SPECIFIC_EXPRESSION_CODES.get(type(node))
        if specific is not None:
            raise _Reject(specific)
        if isinstance(node, ast.Constant):
            self._constant(node)
            return
        if isinstance(node, ast.Name):
            self.name(node.id)
            return
        if isinstance(node, (ast.List, ast.Tuple)):
            for element in node.elts:
                self.expression(element)
            return
        if isinstance(node, ast.Dict):
            self._dict(node)
            return
        if isinstance(node, ast.Subscript):
            self.expression(node.value)
            self._slice(node.slice)
            return
        if isinstance(node, ast.BinOp):
            if not isinstance(node.op, _ALLOWED_BINOPS):
                raise _Reject("E_OPERATOR")
            self.expression(node.left)
            self.expression(node.right)
            return
        if isinstance(node, ast.UnaryOp):
            if not isinstance(node.op, _ALLOWED_UNARYOPS):
                raise _Reject("E_OPERATOR")
            self.expression(node.operand)
            return
        if isinstance(node, ast.BoolOp):
            if not isinstance(node.op, _ALLOWED_BOOLOPS) or len(node.values) < 2:
                raise _Reject("E_OPERATOR")
            for value in node.values:
                self.expression(value)
            return
        if isinstance(node, ast.Compare):
            for operator in node.ops:
                if not isinstance(operator, _ALLOWED_CMPOPS):
                    raise _Reject("E_OPERATOR")
            self.expression(node.left)
            for comparator in node.comparators:
                self.expression(comparator)
            return
        if isinstance(node, ast.IfExp):
            self.expression(node.test)
            self.expression(node.body)
            self.expression(node.orelse)
            return
        if isinstance(node, ast.Call):
            self._call(node)
            return
        raise _Reject("E_EXPRESSION")

    def _constant(self, node: ast.Constant) -> None:
        value = node.value
        if value is None or isinstance(value, bool):
            return
        if isinstance(value, (str, int)):
            return
        if isinstance(value, float):
            if value != value or value in (float("inf"), float("-inf")):
                raise _Reject("E_CONSTANT")
            return
        raise _Reject("E_CONSTANT")

    def _dict(self, node: ast.Dict) -> None:
        seen: set[str] = set()
        for key, value in zip(node.keys, node.values):
            if key is None:
                raise _Reject("E_DICT")
            if not isinstance(key, ast.Constant) or not isinstance(key.value, str):
                raise _Reject("E_DICT")
            if key.value in seen:
                raise _Reject("E_DUP_KEY")
            seen.add(key.value)
            self.expression(value)

    def _slice(self, node: ast.expr | ast.Slice) -> None:
        if isinstance(node, ast.Slice):
            for part in (node.lower, node.upper, node.step):
                if part is not None:
                    self.expression(part)
            return
        self.expression(node)  # type: ignore[arg-type]

    def _call(self, node: ast.Call) -> None:
        if node.keywords:
            raise _Reject("E_KEYWORDS")
        if not isinstance(node.func, ast.Name):
            # Surface the most specific rejection for the callee expression,
            # then fail closed on a non-Name callee.
            self.expression(node.func)
            raise _Reject("E_CALL")
        name = node.func.id
        for argument in node.args:
            if isinstance(argument, ast.Starred):
                raise _Reject("E_STARRED")
        if name in PURE_BUILTINS:
            for argument in node.args:
                self.expression(argument)
            return
        if name == "call_skill":
            if len(node.args) != 2:
                raise _Reject("E_CALL")
            target = node.args[0]
            if not isinstance(target, ast.Constant) or not isinstance(target.value, str):
                raise _Reject("E_CALL")
            if not SKILL_ID_PATTERN.match(target.value):
                raise _Reject("E_CALL")
            self.expression(node.args[1])
            return
        raise _Reject("E_CALL")


def _is_name(node: ast.expr, expected: str) -> bool:
    return isinstance(node, ast.Name) and node.id == expected
