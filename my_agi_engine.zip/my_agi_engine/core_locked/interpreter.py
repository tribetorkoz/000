"""Step-bounded interpreter for the frozen skill grammar.

The interpreter walks the AST produced by :func:`..ast_guard.validate_skill_source`
and evaluates it with an explicit, hand-written evaluator. It never calls
``eval``, ``exec``, ``compile``, ``FunctionType``, ``getattr``, ``pickle``, or
a subprocess, and it never produces Python bytecode.

Guarantees are counted-step guarantees, not a wall-clock hard kill. The
deadline is polled at every charged step. This is a capability-restricted
interpreter boundary, not an OS-level sandbox.

Error codes (stable):
``GUARD_<CODE>``, ``INVALID_BUDGET``, ``INVALID_PAYLOAD``, ``PAYLOAD_TOO_COMPLEX``,
``STEP_BUDGET_EXHAUSTED``, ``DEADLINE_EXCEEDED``, ``UNKNOWN_NAME``,
``TYPE_ERROR``, ``DIVISION_BY_ZERO``, ``INT_OVERFLOW``, ``NON_FINITE_FLOAT``,
``INDEX_ERROR``, ``KEY_ERROR``, ``SLICE_ERROR``, ``RANGE_TOO_LARGE``,
``BUILTIN_LIMIT``, ``VALUE_ERROR``, ``SKILL_NOT_APPROVED``,
``SKILL_SOURCE_REJECTED``, ``CALL_DEPTH_EXCEEDED``, ``SKILL_CYCLE``,
``STRING_TOO_LARGE``, ``INVALID_OUTPUT``, ``OUTPUT_TOO_LARGE``.
"""

from __future__ import annotations

import ast
import math
import time
from typing import Callable

from ..contracts import Budget, ExecutionResult, JSONValue, RunStatus, SkillArtifact, SkillResolver
from .ast_guard import PURE_BUILTINS, validate_skill_source
from .canonical import canonical_json

__all__ = ["interpret_skill", "MAX_CALL_DEPTH", "MAX_RANGE_ITERATIONS"]

MAX_CALL_DEPTH = 8
MAX_RANGE_ITERATIONS = 1000
_MAX_INT_BITS = 4096
_MAX_SORT_INPUT = 1024
_MAX_PAYLOAD_DEPTH = 32
_MAX_PAYLOAD_VALUES = 10000
_MAX_STRING_CHARS = 65536
_MAX_CONTAINER_ENTRIES = 4096
_MAX_STRING_RESULT_CHARS = 65536

#: Compared nodes per charged step inside ``_json_equal``. Small enough that a
#: long comparison is interrupted quickly by the deadline check that ``charge``
#: performs (256 comparisons is well under a millisecond), and large enough
#: that ordinary comparisons are priced sensibly: a 4096-node comparison costs
#: 16 steps, so the default 5000-step budget admits hundreds of them instead of
#: the 76 that a 64-node divisor allowed (A01b-N4).
_COMPARE_WORK_PER_STEP = 256

#: Values per charged step inside ``_bounded_walk``. Every traversal that can
#: be driven by skill-controlled data is metered through that one helper, so
#: copy, validation, size estimation and the dependency walk share a single
#: charged, deadline-aware accounting path (A01b-N1, A01b-N2, A01b-N7).
_WALK_WORK_PER_STEP = 64

#: Upper bound on the canonical-JSON size of one float, in characters.
_MAX_FLOAT_CHARS = 32

#: Sentinel for an exhausted comparison frame (never a JSON value).
_EXHAUSTED = object()

_BLOCKED_CODES = frozenset(
    {
        "INVALID_BUDGET",
        "INVALID_PAYLOAD",
        "PAYLOAD_TOO_COMPLEX",
        "STEP_BUDGET_EXHAUSTED",
        "DEADLINE_EXCEEDED",
        "RANGE_TOO_LARGE",
        "BUILTIN_LIMIT",
        "SKILL_NOT_APPROVED",
        "SKILL_SOURCE_REJECTED",
        "CALL_DEPTH_EXCEEDED",
        "SKILL_CYCLE",
        "OUTPUT_TOO_LARGE",
    }
)


class _SkillError(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class _ReturnSignal(Exception):
    def __init__(self, value: JSONValue) -> None:
        super().__init__("return")
        self.value = value


class _Tracker:
    """Shared step and deadline accounting for one top-level interpretation."""

    __slots__ = ("clock", "deadline", "steps_left", "steps_used", "started")

    def __init__(self, budget: Budget, clock: Callable[[], float]) -> None:
        self.clock = clock
        self.started = clock()
        self.deadline = self.started + float(budget.deadline_seconds)
        self.steps_left = int(budget.max_skill_steps)
        self.steps_used = 0

    def charge(self, count: int = 1) -> None:
        if count < 0:
            raise _SkillError("INVALID_BUDGET")
        if count > self.steps_left:
            raise _SkillError("STEP_BUDGET_EXHAUSTED")
        self.steps_left -= count
        self.steps_used += count
        if self.clock() > self.deadline:
            raise _SkillError("DEADLINE_EXCEEDED")

    def check_deadline(self) -> None:
        if self.clock() > self.deadline:
            raise _SkillError("DEADLINE_EXCEEDED")

    def elapsed_ms(self) -> int:
        return max(0, int(round((self.clock() - self.started) * 1000)))


def interpret_skill(
    source: str,
    payload: JSONValue,
    budget: Budget,
    resolver: SkillResolver | None = None,
    *,
    clock: Callable[[], float] | None = None,
) -> ExecutionResult:
    """Validate and interpret one skill source against *payload*.

    ``clock`` is a test seam only; production callers use the default
    monotonic clock.
    """
    ticker: Callable[[], float] = time.monotonic if clock is None else clock
    if not isinstance(budget, Budget):
        return ExecutionResult(RunStatus.BLOCKED, None, 0, 0, "INVALID_BUDGET")

    tracker = _Tracker(budget, ticker)
    guard = validate_skill_source(source, max_source_bytes=budget.max_artifact_bytes)
    if not guard.accepted or guard.module is None:
        code = guard.codes[0] if guard.codes else "E_SYNTAX"
        return ExecutionResult(RunStatus.BLOCKED, None, 0, tracker.elapsed_ms(), f"GUARD_{code}")

    try:
        _bounded_walk(
            payload,
            tracker=tracker,
            max_bytes=budget.max_payload_bytes,
            too_large_code="PAYLOAD_TOO_COMPLEX",
        )
    except _SkillError as error:
        return _failure(error, tracker, 0)

    interpreter = _Interpreter(tracker, resolver, budget, call_depth=0, call_stack=())
    try:
        output = interpreter.run(guard.module, payload)
    except _SkillError as error:
        return _failure(error, tracker, interpreter.steps())
    except _ReturnSignal:  # pragma: no cover - defensive; run() absorbs returns
        return ExecutionResult(RunStatus.ERROR, None, interpreter.steps(), tracker.elapsed_ms(),
                               "INVALID_OUTPUT")
    except RecursionError:
        return ExecutionResult(RunStatus.BLOCKED, None, interpreter.steps(), tracker.elapsed_ms(),
                               "CALL_DEPTH_EXCEEDED")
    except Exception:  # noqa: BLE001 - never leak tracebacks to callers
        return ExecutionResult(RunStatus.ERROR, None, interpreter.steps(), tracker.elapsed_ms(),
                               "INTERNAL_ERROR")

    try:
        # Decide the size, and pay for the traversal, before materialising the
        # encoded text (A01b-N2). The estimate is an upper bound, so anything
        # rejected here would have been over the cap anyway.
        _bounded_walk(
            output,
            tracker=tracker,
            max_bytes=budget.max_payload_bytes,
            too_large_code="OUTPUT_TOO_LARGE",
        )
    except _SkillError as error:
        return _failure(error, tracker, interpreter.steps())
    tracker.check_deadline()
    try:
        encoded = canonical_json(output).encode("utf-8")
    except Exception:  # noqa: BLE001
        return ExecutionResult(RunStatus.ERROR, None, interpreter.steps(), tracker.elapsed_ms(),
                               "INVALID_OUTPUT")
    tracker.check_deadline()
    if len(encoded) > budget.max_payload_bytes:
        return ExecutionResult(RunStatus.BLOCKED, None, interpreter.steps(), tracker.elapsed_ms(),
                               "OUTPUT_TOO_LARGE")
    return ExecutionResult(RunStatus.OK, output, interpreter.steps(), tracker.elapsed_ms(), None)


def _failure(error: _SkillError, tracker: _Tracker, steps: int) -> ExecutionResult:
    status = RunStatus.BLOCKED if error.code in _BLOCKED_CODES else RunStatus.ERROR
    return ExecutionResult(status, None, steps, tracker.elapsed_ms(), error.code)


def _validate_payload(value: object) -> None:
    _bounded_walk(value)


class _WalkMeter:
    """Charged, deadline-aware accounting for one JSON traversal.

    ``values`` counts *logical* values, so a structure that shares its inner
    containers is charged for every occurrence, exactly as it would be if it
    were serialised. ``bytes`` is a conservative **upper bound** on the
    canonical JSON size, so a caller can refuse a value before paying to
    encode it.
    """

    __slots__ = ("bytes", "max_bytes", "too_large_code", "tracker", "units", "values")

    def __init__(
        self,
        tracker: "_Tracker | None",
        max_bytes: int | None,
        too_large_code: str,
    ) -> None:
        self.tracker = tracker
        self.max_bytes = max_bytes
        self.too_large_code = too_large_code
        self.values = 0
        self.bytes = 0
        self.units = 0

    def visit(self, size: int) -> None:
        self.values += 1
        if self.values > _MAX_PAYLOAD_VALUES:
            raise _SkillError("PAYLOAD_TOO_COMPLEX")
        self.bytes += size
        if self.max_bytes is not None and self.bytes > self.max_bytes:
            raise _SkillError(self.too_large_code)
        if self.tracker is not None:
            self.units += 1
            if self.units % _WALK_WORK_PER_STEP == 0:
                self.tracker.charge(1)

    def charge_remaining(self) -> None:
        if self.tracker is not None and self.units % _WALK_WORK_PER_STEP:
            self.tracker.charge(1)


def _string_size(text: str) -> int:
    """Upper bound on the canonical-JSON size of *text*, in bytes.

    ``canonical_json`` uses ``ensure_ascii=False``, so printable non-ASCII
    text stays raw (1-4 UTF-8 bytes per character) while control characters
    become six-character ``\\uXXXX`` escapes. Both are accounted for, because
    a sixfold expansion is what makes an output cap checkable only *after* the
    expensive encode (A01b-N2).
    """
    total = 2  # the surrounding quotes
    for char in text:
        point = ord(char)
        if point < 0x20:
            total += 6
        elif char in '"\\':
            total += 2
        elif point < 0x80:
            total += 1
        elif point < 0x800:
            total += 2
        elif point < 0x10000:
            total += 3
        else:
            total += 4
    return total


def _bounded_walk(
    value: object,
    *,
    tracker: "_Tracker | None" = None,
    max_bytes: int | None = None,
    too_large_code: str = "PAYLOAD_TOO_COMPLEX",
) -> int:
    """Validate *value*, charge the traversal, and return a size upper bound.

    This is the one governed path for work driven by skill-controlled values.
    It is iterative, so depth cannot exhaust the interpreter stack; it counts
    values *logically*, so shared inner containers are charged for every
    occurrence instead of being copied for free; it polls the deadline through
    ``tracker.charge`` every :data:`_WALK_WORK_PER_STEP` values; and it stops
    on the byte estimate instead of after an allocation.

    Raises :class:`_SkillError` with ``PAYLOAD_TOO_COMPLEX``, ``INVALID_PAYLOAD``
    or *too_large_code*.
    """
    meter = _WalkMeter(tracker, max_bytes, too_large_code)
    stack: list[tuple[object, int]] = [(value, 0)]
    while stack:
        item, depth = stack.pop()
        if depth > _MAX_PAYLOAD_DEPTH:
            raise _SkillError("PAYLOAD_TOO_COMPLEX")
        if item is None:
            meter.visit(4)
        elif item is True:
            meter.visit(4)
        elif item is False:
            meter.visit(5)
        elif isinstance(item, int):
            meter.visit(len(str(item)) + 1)
        elif isinstance(item, float):
            if not math.isfinite(item):
                raise _SkillError("INVALID_PAYLOAD")
            meter.visit(_MAX_FLOAT_CHARS)
        elif isinstance(item, str):
            if len(item) > _MAX_STRING_CHARS:
                raise _SkillError("PAYLOAD_TOO_COMPLEX")
            # Every character costs at least one byte, so this bounds the
            # scan that follows.
            if meter.max_bytes is not None and meter.bytes + len(item) > meter.max_bytes:
                raise _SkillError(meter.too_large_code)
            meter.visit(_string_size(item))
        elif isinstance(item, list):
            if len(item) > _MAX_CONTAINER_ENTRIES:
                raise _SkillError("PAYLOAD_TOO_COMPLEX")
            meter.visit(2 + max(0, len(item) - 1))
            stack.extend((child, depth + 1) for child in item)
        elif isinstance(item, dict):
            if len(item) > _MAX_CONTAINER_ENTRIES:
                raise _SkillError("PAYLOAD_TOO_COMPLEX")
            meter.visit(2 + max(0, len(item) - 1))
            for key, child in item.items():
                if not isinstance(key, str):
                    raise _SkillError("INVALID_PAYLOAD")
                if len(key) > _MAX_STRING_CHARS:
                    raise _SkillError("PAYLOAD_TOO_COMPLEX")
                if meter.max_bytes is not None and meter.bytes + len(key) > meter.max_bytes:
                    raise _SkillError(meter.too_large_code)
                meter.visit(_string_size(key) + 1)
                stack.append((child, depth + 1))
        else:
            raise _SkillError("INVALID_PAYLOAD")
    meter.charge_remaining()
    return meter.bytes


def _copy_json(value: JSONValue) -> JSONValue:
    if isinstance(value, list):
        return [_copy_json(item) for item in value]
    if isinstance(value, dict):
        return {key: _copy_json(item) for key, item in value.items()}
    return value


class _Interpreter:
    __slots__ = ("budget", "call_depth", "call_stack", "env", "resolver", "tracker")

    def __init__(
        self,
        tracker: _Tracker,
        resolver: SkillResolver | None,
        budget: Budget,
        *,
        call_depth: int,
        call_stack: tuple[str, ...],
    ) -> None:
        self.tracker = tracker
        self.resolver = resolver
        self.budget = budget
        self.call_depth = call_depth
        self.call_stack = call_stack
        self.env: dict[str, JSONValue] = {}

    # -- driver ---------------------------------------------------------

    def run(self, module: object, payload: JSONValue) -> JSONValue:
        assert isinstance(module, ast.Module)
        function = module.body[0]
        assert isinstance(function, ast.FunctionDef)
        self.env = {"data": _copy_json(payload)}
        try:
            for statement in function.body:
                self.statement(statement)
        except _ReturnSignal as signal:
            return signal.value
        return None

    def steps(self) -> int:
        return self.tracker.steps_used

    # -- statements -----------------------------------------------------

    def statement(self, node: object) -> None:
        self.tracker.charge(1)
        if isinstance(node, ast.Assign):
            value = self.expression(node.value)
            self.env[node.targets[0].id] = value  # type: ignore[attr-defined]
            return
        if isinstance(node, ast.If):
            if _truthy(self.expression(node.test)):
                for child in node.body:
                    self.statement(child)
            else:
                for child in node.orelse:
                    self.statement(child)
            return
        if isinstance(node, ast.For):
            iterable = self.expression(node.iter)
            if not isinstance(iterable, list):
                raise _SkillError("TYPE_ERROR")
            target = node.target.id  # type: ignore[attr-defined]
            for item in iterable:
                self.tracker.charge(1)
                self.env[target] = item
                for child in node.body:
                    self.statement(child)
            return
        if isinstance(node, ast.Expr):
            self.expression(node.value)
            return
        if isinstance(node, ast.Return):
            raise _ReturnSignal(self.expression(node.value) if node.value is not None else None)
        raise _SkillError("TYPE_ERROR")

    # -- expressions ----------------------------------------------------

    def expression(self, node: object) -> JSONValue:
        self.tracker.charge(1)
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            if node.id not in self.env:
                raise _SkillError("UNKNOWN_NAME")
            return self.env[node.id]
        if isinstance(node, (ast.List, ast.Tuple)):
            items = [self.expression(element) for element in node.elts]
            if len(items) > _MAX_CONTAINER_ENTRIES:
                raise _SkillError("PAYLOAD_TOO_COMPLEX")
            self.tracker.charge(len(items))
            return items
        if isinstance(node, ast.Dict):
            result: dict[str, JSONValue] = {}
            for key, value_node in zip(node.keys, node.values):
                key_value = self.expression(key)  # type: ignore[arg-type]
                if not isinstance(key_value, str):
                    raise _SkillError("TYPE_ERROR")
                result[key_value] = self.expression(value_node)
            self.tracker.charge(len(result))
            return result
        if isinstance(node, ast.Subscript):
            container = self.expression(node.value)
            return self._subscript(container, node.slice)
        if isinstance(node, ast.BinOp):
            left = self.expression(node.left)
            right = self.expression(node.right)
            return self._binop(node.op, left, right)  # type: ignore[arg-type]
        if isinstance(node, ast.UnaryOp):
            return self._unaryop(node.op, self.expression(node.operand))  # type: ignore[arg-type]
        if isinstance(node, ast.BoolOp):
            if isinstance(node.op, ast.And):
                value: JSONValue = True
                for child in node.values:
                    value = self.expression(child)
                    if not _truthy(value):
                        return value
                return value
            value = False
            for child in node.values:
                value = self.expression(child)
                if _truthy(value):
                    return value
            return value
        if isinstance(node, ast.Compare):
            left = self.expression(node.left)
            for operator, comparator in zip(node.ops, node.comparators):
                right = self.expression(comparator)
                if not _compare(operator, left, right, self.tracker):
                    return False
                left = right
            return True
        if isinstance(node, ast.IfExp):
            return self.expression(node.body) if _truthy(self.expression(node.test)) else self.expression(node.orelse)
        if isinstance(node, ast.Call):
            return self._call(node)
        raise _SkillError("TYPE_ERROR")

    # -- operations -----------------------------------------------------

    def _subscript(self, container: JSONValue, slice_node: object) -> JSONValue:
        if isinstance(slice_node, ast.Slice):
            return self._slice(container, slice_node)
        index = self.expression(slice_node)  # type: ignore[arg-type]
        if isinstance(container, list):
            position = _as_index(index)
            if position < 0:
                position += len(container)
            if position < 0 or position >= len(container):
                raise _SkillError("INDEX_ERROR")
            return container[position]
        if isinstance(container, str):
            position = _as_index(index)
            if position < 0:
                position += len(container)
            if position < 0 or position >= len(container):
                raise _SkillError("INDEX_ERROR")
            return container[position]
        if isinstance(container, dict):
            if not isinstance(index, str):
                raise _SkillError("TYPE_ERROR")
            if index not in container:
                raise _SkillError("KEY_ERROR")
            return container[index]
        raise _SkillError("TYPE_ERROR")

    def _slice(self, container: JSONValue, node: object) -> JSONValue:
        assert isinstance(node, ast.Slice)
        parts: list[int | None] = []
        for part in (node.lower, node.upper, node.step):
            if part is None:
                parts.append(None)
            else:
                value = self.expression(part)
                parts.append(_as_index(value))
        start, stop, step = parts
        if step == 0:
            raise _SkillError("SLICE_ERROR")
        if isinstance(container, (list, str)):
            result = container[slice(start, stop, step)]
            self.tracker.charge(len(result))
            return result
        raise _SkillError("TYPE_ERROR")

    def _binop(self, operator: object, left: JSONValue, right: JSONValue) -> JSONValue:
        if isinstance(operator, ast.Add):
            if isinstance(left, str) and isinstance(right, str):
                if len(left) + len(right) > _MAX_STRING_RESULT_CHARS:
                    raise _SkillError("STRING_TOO_LARGE")
                return left + right
            if isinstance(left, list) and isinstance(right, list):
                if len(left) + len(right) > _MAX_CONTAINER_ENTRIES:
                    raise _SkillError("PAYLOAD_TOO_COMPLEX")
                return left + right
            return _numeric(operator, left, right)
        if isinstance(operator, ast.Sub):
            return _numeric(operator, left, right)
        if isinstance(operator, ast.Mult):
            if isinstance(left, str) and isinstance(right, int) and not isinstance(right, bool):
                return _bounded_repeat(left, right)
            if isinstance(left, int) and not isinstance(left, bool) and isinstance(right, str):
                return _bounded_repeat(right, left)
            if isinstance(left, list) and isinstance(right, int) and not isinstance(right, bool):
                count = right if right > 0 else 0
                if len(left) * count > _MAX_CONTAINER_ENTRIES:
                    raise _SkillError("PAYLOAD_TOO_COMPLEX")
                return left * count
            return _numeric(operator, left, right)
        if isinstance(operator, ast.FloorDiv):
            if _is_number(left) and _is_number(right):
                if right == 0:
                    raise _SkillError("DIVISION_BY_ZERO")
                return _check_number(left // right)
            raise _SkillError("TYPE_ERROR")
        if isinstance(operator, ast.Mod):
            if _is_number(left) and _is_number(right):
                if right == 0:
                    raise _SkillError("DIVISION_BY_ZERO")
                return _check_number(left % right)
            if isinstance(left, str):
                raise _SkillError("TYPE_ERROR")
            raise _SkillError("TYPE_ERROR")
        raise _SkillError("TYPE_ERROR")

    def _unaryop(self, operator: object, operand: JSONValue) -> JSONValue:
        if isinstance(operator, ast.Not):
            return not _truthy(operand)
        if not _is_number(operand):
            raise _SkillError("TYPE_ERROR")
        if isinstance(operator, ast.USub):
            return _check_number(-operand)  # type: ignore[operator]
        if isinstance(operator, ast.UAdd):
            return _check_number(+operand)  # type: ignore[operator]
        raise _SkillError("TYPE_ERROR")

    # -- calls ----------------------------------------------------------

    def _call(self, node: object) -> JSONValue:
        assert isinstance(node, ast.Call)
        assert isinstance(node.func, ast.Name)
        name = node.func.id
        arguments = [self.expression(argument) for argument in node.args]
        if name in PURE_BUILTINS:
            return self._builtin(name, arguments)
        if name == "call_skill":
            skill_id = arguments[0]
            assert isinstance(skill_id, str)
            return self._call_skill(skill_id, arguments[1])
        raise _SkillError("UNKNOWN_NAME")

    def _builtin(self, name: str, arguments: list[JSONValue]) -> JSONValue:
        if name == "len":
            _expect_arity(name, arguments, 1)
            target = arguments[0]
            if isinstance(target, (str, list, dict)):
                return len(target)
            raise _SkillError("TYPE_ERROR")
        if name == "range":
            return _range(arguments)
        if name == "abs":
            _expect_arity(name, arguments, 1)
            value = arguments[0]
            if not _is_number(value):
                raise _SkillError("TYPE_ERROR")
            self.tracker.charge(1)
            return _check_number(abs(value))  # type: ignore[arg-type]
        if name == "round":
            if len(arguments) not in (1, 2):
                raise _SkillError("VALUE_ERROR")
            value = arguments[0]
            if not _is_number(value):
                raise _SkillError("TYPE_ERROR")
            digits = None
            if len(arguments) == 2:
                digits = _as_index(arguments[1])
                if digits < -20 or digits > 20:
                    raise _SkillError("VALUE_ERROR")
            self.tracker.charge(1)
            result = round(value, digits) if digits is not None else round(value)  # type: ignore[arg-type]
            return _check_number(result)
        if name == "sum":
            _expect_arity(name, arguments, 1)
            target = arguments[0]
            if not isinstance(target, list):
                raise _SkillError("TYPE_ERROR")
            if len(target) > _MAX_SORT_INPUT:
                raise _SkillError("BUILTIN_LIMIT")
            self.tracker.charge(len(target))
            total: int | float = 0
            for item in target:
                if not _is_number(item):
                    raise _SkillError("TYPE_ERROR")
                total = total + item  # type: ignore[operator]
            return _check_number(total)
        if name in ("min", "max"):
            if not arguments:
                raise _SkillError("VALUE_ERROR")
            if len(arguments) == 1 and isinstance(arguments[0], list):
                values = arguments[0]
                if not values:
                    raise _SkillError("VALUE_ERROR")
                if len(values) > _MAX_SORT_INPUT:
                    raise _SkillError("BUILTIN_LIMIT")
            else:
                values = arguments
            self.tracker.charge(len(values))
            best = values[0]
            _require_orderable(best)
            for candidate in values[1:]:
                _require_orderable(candidate)
                if not _same_ordering_domain(best, candidate):
                    raise _SkillError("TYPE_ERROR")
                if (name == "min" and candidate < best) or (name == "max" and candidate > best):  # type: ignore[operator]
                    best = candidate
            return best
        if name == "sorted":
            _expect_arity(name, arguments, 1)
            target = arguments[0]
            if not isinstance(target, list):
                raise _SkillError("TYPE_ERROR")
            if len(target) > _MAX_SORT_INPUT:
                raise _SkillError("BUILTIN_LIMIT")
            for item in target:
                _require_orderable(item)
            if target:
                first = target[0]
                for item in target[1:]:
                    if not _same_ordering_domain(first, item):
                        raise _SkillError("TYPE_ERROR")
            self.tracker.charge(max(1, len(target)))
            return sorted(target)
        raise _SkillError("UNKNOWN_NAME")

    def _call_skill(self, skill_id: str, payload: JSONValue) -> JSONValue:
        if self.resolver is None:
            raise _SkillError("SKILL_NOT_APPROVED")
        if skill_id in self.call_stack:
            raise _SkillError("SKILL_CYCLE")
        if self.call_depth + 1 > MAX_CALL_DEPTH:
            raise _SkillError("CALL_DEPTH_EXCEEDED")
        skill = self.resolver.get_approved(skill_id)
        if not isinstance(skill, SkillArtifact):
            raise _SkillError("SKILL_NOT_APPROVED")
        # The resolver is the approval authority, but the artifact's own
        # identity is what a manifest approves. A resolver that returns a
        # different artifact must not turn "call safe" into "run evil".
        if skill.skill_id != skill_id:
            raise _SkillError("SKILL_NOT_APPROVED")
        # The payload here is built by the calling skill, not by the host, so
        # it has not passed the top-level payload check. Validate and charge it
        # at this boundary: copying an unbounded argument would otherwise do
        # work that neither the step budget nor the deadline can see
        # (A01b-N1).
        _bounded_walk(
            payload,
            tracker=self.tracker,
            max_bytes=self.budget.max_payload_bytes,
        )
        guard = validate_skill_source(skill.source, max_source_bytes=self.budget.max_artifact_bytes)
        if not guard.accepted or guard.module is None:
            raise _SkillError("SKILL_SOURCE_REJECTED")
        self.tracker.charge(1)
        nested = _Interpreter(
            self.tracker,
            self.resolver,
            self.budget,
            call_depth=self.call_depth + 1,
            call_stack=self.call_stack + (skill_id,),
        )
        try:
            return nested.run(guard.module, payload)
        except _ReturnSignal as signal:  # pragma: no cover - run() absorbs returns
            return signal.value


def _expect_arity(name: str, arguments: list[JSONValue], count: int) -> None:
    if len(arguments) != count:
        raise _SkillError("VALUE_ERROR")


def _range(arguments: list[JSONValue]) -> JSONValue:
    if not 1 <= len(arguments) <= 3:
        raise _SkillError("VALUE_ERROR")
    values: list[int] = []
    for argument in arguments:
        if isinstance(argument, bool) or not isinstance(argument, int):
            raise _SkillError("TYPE_ERROR")
        values.append(argument)
    if len(values) == 1:
        start, stop, step = 0, values[0], 1
    elif len(values) == 2:
        start, stop, step = values[0], values[1], 1
    else:
        start, stop, step = values[0], values[1], values[2]
    if step == 0:
        raise _SkillError("VALUE_ERROR")
    span = stop - start
    length = 0 if span == 0 else (span + step - (1 if step > 0 else -1)) // step
    length = max(0, length)
    if length > MAX_RANGE_ITERATIONS:
        raise _SkillError("RANGE_TOO_LARGE")
    return [start + index * step for index in range(length)]


def _is_number(value: JSONValue) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _check_number(value: object) -> JSONValue:
    if isinstance(value, bool):
        raise _SkillError("TYPE_ERROR")
    if isinstance(value, int):
        if value.bit_length() > _MAX_INT_BITS:
            raise _SkillError("INT_OVERFLOW")
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise _SkillError("NON_FINITE_FLOAT")
        return value
    raise _SkillError("TYPE_ERROR")


def _numeric(operator: object, left: JSONValue, right: JSONValue) -> JSONValue:
    if not _is_number(left) or not _is_number(right):
        raise _SkillError("TYPE_ERROR")
    if operator.__class__.__name__ == "Add":
        return _check_number(left + right)  # type: ignore[operator]
    if operator.__class__.__name__ == "Sub":
        return _check_number(left - right)  # type: ignore[operator]
    if operator.__class__.__name__ == "Mult":
        return _check_number(left * right)  # type: ignore[operator]
    raise _SkillError("TYPE_ERROR")


def _bounded_repeat(text: str, count: int) -> str:
    """Repeat *text* only after proving the result fits the string cap.

    The proof has to come first. ``'a' * 500000000`` allocates half a gigabyte
    before a post-hoc length check could reject it, which is a memory
    amplification path rather than a string-length error.
    """
    repeats = count if count > 0 else 0
    if len(text) * repeats > _MAX_STRING_RESULT_CHARS:
        raise _SkillError("STRING_TOO_LARGE")
    return text * repeats


def _as_index(value: JSONValue) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise _SkillError("TYPE_ERROR")
    return value


def _require_orderable(value: JSONValue) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise _SkillError("TYPE_ERROR")


def _same_ordering_domain(left: JSONValue, right: JSONValue) -> bool:
    left_number = _is_number(left)
    right_number = _is_number(right)
    if left_number and right_number:
        return True
    return isinstance(left, str) and isinstance(right, str)


def _compare(
    operator: object,
    left: JSONValue,
    right: JSONValue,
    tracker: "_Tracker",
) -> bool:
    if isinstance(operator, (ast.Eq, ast.NotEq)):
        equal = _json_equal(left, right, tracker)
        return equal if isinstance(operator, ast.Eq) else not equal
    _require_orderable(left)
    _require_orderable(right)
    if not _same_ordering_domain(left, right):
        raise _SkillError("TYPE_ERROR")
    if isinstance(operator, ast.Lt):
        return left < right  # type: ignore[operator]
    if isinstance(operator, ast.LtE):
        return left <= right  # type: ignore[operator]
    if isinstance(operator, ast.Gt):
        return left > right  # type: ignore[operator]
    if isinstance(operator, ast.GtE):
        return left >= right  # type: ignore[operator]
    raise _SkillError("TYPE_ERROR")


def _json_equal(left: JSONValue, right: JSONValue, tracker: "_Tracker") -> bool:
    """Structural JSON equality with counted, deadline-aware work.

    The walk is iterative, charged in blocks of
    :data:`_COMPARE_WORK_PER_STEP` compared nodes, and keeps **one frame per
    nesting level** (an iterator over the current container's child pairs)
    rather than a stack of every pending pair. That matters three times over:

    * A skill can build nested lists that *share* their inner object
      (``grid = [inner] * n``), so the logical element count is ``n ** depth``
      while memory stays small. Without charging, a single ``==`` step would
      perform that entire product of comparisons.
    * Charging calls :meth:`_Tracker.charge`, which polls the deadline, so the
      wall-clock limit is enforced *inside* a long operation instead of only
      between steps.
    * Frame-per-level keeps the comparison's own memory proportional to
      nesting depth instead of to the number of pending pairs, so the memory
      ceiling is a function of the documented limits rather than of the
      breadth of the value (A01b-N3).

    Iteration also removes recursion-depth failures: structure depth is not
    bounded by the payload walk here because skills can build their own values.
    """
    work = 0
    stack: list[object] = []
    left_item, right_item = left, right
    while True:
        work += 1
        if work % _COMPARE_WORK_PER_STEP == 0:
            tracker.charge(1)
        children: object = None
        if isinstance(left_item, bool) or isinstance(right_item, bool):
            if not (
                isinstance(left_item, bool)
                and isinstance(right_item, bool)
                and left_item is right_item
            ):
                return False
        elif _is_number(left_item) and _is_number(right_item):
            if left_item != right_item:
                return False
        elif isinstance(left_item, str) and isinstance(right_item, str):
            if left_item != right_item:
                return False
        elif isinstance(left_item, list) and isinstance(right_item, list):
            if len(left_item) != len(right_item):
                return False
            children = zip(left_item, right_item)
        elif isinstance(left_item, dict) and isinstance(right_item, dict):
            if left_item.keys() != right_item.keys():
                return False
            children = ((left_item[key], right_item[key]) for key in left_item)
        else:
            return False
        if children is not None:
            stack.append(children)
        # Take the next pending pair; unwind finished frames. A frame is one
        # iterator, so the stack holds at most one entry per nesting level.
        while stack:
            pending = next(stack[-1], _EXHAUSTED)
            if pending is not _EXHAUSTED:
                left_item, right_item = pending
                break
            stack.pop()
        else:
            return True


def _truthy(value: JSONValue) -> bool:
    if value is None or value is False or value is True:
        return value is True
    if _is_number(value):
        return value != 0  # type: ignore[operator]
    if isinstance(value, (str, list, dict)):
        return len(value) > 0
    return False
