"""Replaceable harness policies: model adapters, search, skills, controller.

Everything here may be proposed for change at runtime, but only as inert
records. Nothing in this package holds approval authority.
"""
